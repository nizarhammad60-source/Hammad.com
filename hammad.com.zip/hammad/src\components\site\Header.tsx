import { Link } from "@tanstack/react-router";
import { ShoppingBag, Menu, X, LayoutDashboard, Zap } from "lucide-react";
import { useState, useEffect } from "react";
import { useCart } from "@/lib/cart";
import { useAuth } from "@/lib/auth";

const nav = [
  { to: "/", label: "Home" },
  { to: "/products", label: "Products" },
  { to: "/about", label: "About" },
] as const;

export function Header() {
  const { count, setOpen } = useCart();
  const { isAdmin } = useAuth();
  const [mobile, setMobile] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  return (
    <>
      {/* ── Promo Bar ── */}
      <div className="relative overflow-hidden bg-brand py-2.5 text-brand-foreground">
        <div className="marquee-track text-xs font-semibold uppercase tracking-[0.2em]">
          {Array.from({ length: 8 }).map((_, i) => (
            <span key={i} className="shrink-0 flex items-center gap-3">
              <Zap className="h-3 w-3" />
              Free Express Shipping on Orders Over $150
              <span className="opacity-40 mx-2">✦</span>
              New 2026 Performance Collection
              <span className="opacity-40 mx-2">✦</span>
              Trusted by 120K+ Athletes Worldwide
              <span className="opacity-40 mx-6">·</span>
            </span>
          ))}
        </div>
      </div>

      {/* ── Main Header ── */}
      <header
        className={`sticky top-0 z-50 transition-all duration-500 ${
          scrolled
            ? "glass border-b border-white/5 shadow-[0_8px_32px_rgba(0,0,0,0.5)]"
            : "bg-background/60 backdrop-blur-xl border-b border-white/4"
        }`}
        style={{ backdropFilter: "blur(24px) saturate(160%)" }}
      >
        <div className="container-x flex h-[68px] items-center justify-between gap-6">

          {/* Logo */}
          <Link to="/" className="group flex items-baseline gap-1 shrink-0">
            <span
              className="font-display text-3xl tracking-[0.08em] text-gold-gradient leading-none"
              style={{ fontWeight: 800 }}
            >
              HAMMAD
            </span>
            <span className="text-[10px] text-muted-foreground tracking-widest font-sans font-medium">.COM</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                activeOptions={{ exact: n.to === "/" }}
                className="relative text-sm font-sans font-medium tracking-wide text-muted-foreground transition-colors duration-200 hover:text-foreground hover-underline-gold data-[status=active]:text-foreground data-[status=active]:font-semibold cursor-pointer"
              >
                {n.label}
              </Link>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <Link
              to={isAdmin ? "/admin" : "/login"}
              className="hidden sm:inline-flex h-9 items-center gap-2 rounded-full glass border border-white/8 px-4 text-xs font-medium text-muted-foreground transition-all duration-300 hover:text-foreground hover:border-brand/30 hover:bg-brand/5 cursor-pointer"
            >
              <LayoutDashboard className="h-3.5 w-3.5" />
              {isAdmin ? "Dashboard" : "Sign in"}
            </Link>

            <button
              onClick={() => setOpen(true)}
              aria-label="Open cart"
              className="relative inline-flex h-10 w-10 items-center justify-center rounded-full glass border border-white/8 transition-all duration-300 hover:border-brand/30 hover:bg-brand/5 cursor-pointer"
            >
              <ShoppingBag className="h-[18px] w-[18px] text-foreground" />
              {count > 0 && (
                <span className="absolute -top-1 -right-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-brand px-1 text-[9px] font-bold text-brand-foreground gold-glow">
                  {count}
                </span>
              )}
            </button>

            <button
              onClick={() => setMobile((s) => !s)}
              aria-label="Toggle menu"
              className="md:hidden inline-flex h-10 w-10 items-center justify-center rounded-full glass border border-white/8 hover:border-brand/30 hover:bg-brand/5 transition-all cursor-pointer"
            >
              {mobile ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>

        {/* ── Mobile Menu ── */}
        <div
          className={`md:hidden overflow-hidden transition-all duration-500 ease-in-out ${
            mobile ? "max-h-72 opacity-100" : "max-h-0 opacity-0"
          }`}
        >
          <div style={{ background: "rgba(8,7,6,0.97)", backdropFilter: "blur(20px)" }} className="border-t border-white/5">
            <nav className="container-x flex flex-col py-4 gap-1">
              {nav.map((n) => (
                <Link
                  key={n.to}
                  to={n.to}
                  onClick={() => setMobile(false)}
                  className="flex items-center gap-3 py-3 px-3 rounded-xl text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-white/4 transition-all cursor-pointer"
                >
                  <span className="h-1 w-1 rounded-full bg-brand" />
                  {n.label}
                </Link>
              ))}
              <Link
                to={isAdmin ? "/admin" : "/login"}
                onClick={() => setMobile(false)}
                className="flex items-center gap-3 mt-2 py-3 px-3 rounded-xl text-sm font-medium text-brand hover:bg-brand/8 transition-all cursor-pointer"
              >
                <LayoutDashboard className="h-4 w-4" />
                {isAdmin ? "Dashboard" : "Sign in"}
              </Link>
            </nav>
          </div>
        </div>
      </header>
    </>
  );
}
