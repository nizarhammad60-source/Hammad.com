export type Category =
  | "Fitness Equipment"
  | "Football Gear"
  | "Gym Accessories"
  | "Running Essentials"
  | "Training Wear";

export const CATEGORIES: Category[] = [
  "Fitness Equipment",
  "Football Gear",
  "Gym Accessories",
  "Running Essentials",
  "Training Wear",
];

export const categoriesMeta: { name: Category; blurb: string }[] = [
  { name: "Fitness Equipment", blurb: "Build strength at home" },
  { name: "Football Gear", blurb: "Own the pitch" },
  { name: "Gym Accessories", blurb: "Train every detail" },
  { name: "Running Essentials", blurb: "Go further, faster" },
  { name: "Training Wear", blurb: "Move with intent" },
];

export interface Product {
  id: string;
  name: string;
  description: string;
  long_description: string;
  category: string;
  price: number;
  image_url: string;
  badge: string | null;
  featured: boolean;
  stock: number;
  created_at: string;
  updated_at: string;
}
