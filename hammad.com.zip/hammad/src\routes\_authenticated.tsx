import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated")({
  component: AuthLayout,
});

function AuthLayout() {
  const { session, loading, isAdmin } = useAuth();

  if (loading) {
    return (
      <div className="container-x flex min-h-[60vh] items-center justify-center">
        <p className="text-sm text-muted-foreground">Loading…</p>
      </div>
    );
  }
  if (!session) {
    throw redirect({ to: "/login", search: { redirect: window.location.pathname } });
  }
  if (!isAdmin) {
    return (
      <div className="container-x py-32 text-center">
        <h1 className="font-display text-5xl mb-4 text-gold-gradient" style={{ fontWeight: 900 }}>ACCESS DENIED</h1>
        <p className="mt-3 text-muted-foreground font-sans">Your account doesn't have permission to view the dashboard.</p>
      </div>
    );
  }
  return <Outlet />;
}
