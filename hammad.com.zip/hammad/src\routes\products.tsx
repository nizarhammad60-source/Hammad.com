import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { z } from "zod";
import { SlidersHorizontal, X } from "lucide-react";
import { categoriesMeta, type Category } from "@/lib/products";
import { ProductCard } from "@/components/site/ProductCard";
import { useProducts } from "@/lib/queries";

const searchSchema = z.object({
  category: z.string().optional(),
});

export const Route = createFileRoute("/products")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Products — HAMMAD" },
      { name: "description", content: "Browse premium sports gear: training, football, running, gym accessories and apparel." },
    ],
  }),
  component: ProductsPage,
});

type Sort = "Featured" | "Price: Low to High" | "Price: High to Low" | "New Arrivals";

function ProductsPage() {
  const search = Route.useSearch();
  const initialCat = (search.category as Category | undefined) ?? "All";
  const [cat, setCat] = useState<Category | "All">(initialCat);
  const [sort, setSort] = useState<Sort>("Featured");
  const [maxPrice, setMaxPrice] = useState(500);
  const [mobileFilters, setMobileFilters] = useState(false);
  const { data: products = [], isLoading } = useProducts();

  const filtered = useMemo(() => {
    let list = products.filter((p) => (cat === "All" ? true : p.category === cat));
    list = list.filter((p) => Number(p.price) <= maxPrice);
    switch (sort) {
      case "Price: Low to High": list = [...list].sort((a, b) => Number(a.price) - Number(b.price)); break;
      case "Price: High to Low": list = [...list].sort((a, b) => Number(b.price) - Number(a.price)); break;
      case "New Arrivals": list = [...list].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()); break;
      case "Featured": list = [...list].sort((a, b) => Number(b.featured) - Number(a.featured)); break;
    }
    return list;
  }, [products, cat, sort, maxPrice]);

  const allCategories = ["All", ...categoriesMeta.map((c) => c.name)] as const;

  return (
    <div className="relative">
      {/* Background orb */}
      <div className="orb w-[600px] h-[600px] top-0 right-0 pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(212,169,41,0.05) 0%, transparent 65%)" }} />

      <div className="container-x py-14 md:py-20">
        {/* ── Page Header ── */}
        <div className="max-w-2xl mb-14 fade-up">
          <p className="text-[11px] uppercase tracking-[0.3em] text-brand font-bold mb-3">Catalog</p>
          <h1 className="font-display leading-none tracking-wide"
            style={{ fontSize: "clamp(3rem, 7vw, 6rem)", fontWeight: 900 }}>
            ALL PRODUCTS
          </h1>
          <p className="mt-5 text-muted-foreground font-sans leading-relaxed max-w-lg">
            A focused edit of equipment, apparel, and accessories — chosen for athletes who care about the details.
          </p>
        </div>

        {/* ── Mobile filter toggle ── */}
        <button
          onClick={() => setMobileFilters((s) => !s)}
          className="lg:hidden mb-6 inline-flex items-center gap-2 glass rounded-full border border-white/8 px-5 py-2.5 text-sm font-medium text-foreground hover:border-brand/30 transition-all cursor-pointer"
        >
          <SlidersHorizontal className="h-4 w-4 text-brand" />
          Filters {cat !== "All" && <span className="h-1.5 w-1.5 rounded-full bg-brand" />}
        </button>

        <div className="grid gap-10 lg:grid-cols-[260px_1fr]">

          {/* ── Sidebar ── */}
          <aside
            className={`space-y-8 lg:sticky lg:top-28 lg:self-start transition-all duration-500 ${
              mobileFilters ? "block" : "hidden lg:block"
            }`}
          >
            <div className="glass rounded-2xl border border-white/6 p-6">
              {/* Category */}
              <div className="mb-8">
                <h3 className="font-display text-xs tracking-[0.25em] text-brand mb-4" style={{ fontWeight: 700 }}>
                  CATEGORY
                </h3>
                <ul className="space-y-1">
                  {allCategories.map((c) => (
                    <li key={c}>
                      <button
                        onClick={() => setCat(c as Category | "All")}
                        className={`w-full rounded-xl px-4 py-2.5 text-left text-sm font-medium transition-all duration-200 cursor-pointer ${
                          cat === c
                            ? "glass-gold border border-brand/20 text-brand"
                            : "text-muted-foreground hover:text-foreground hover:bg-white/4"
                        }`}
                      >
                        {c}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Price */}
              <div>
                <h3 className="font-display text-xs tracking-[0.25em] text-brand mb-4" style={{ fontWeight: 700 }}>
                  MAX PRICE
                </h3>
                <input
                  type="range" min={30} max={500} step={10}
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(Number(e.target.value))}
                  className="w-full"
                  aria-label="Maximum price filter"
                />
                <div className="flex items-center justify-between mt-2">
                  <span className="text-xs text-muted-foreground">$30</span>
                  <span className="text-sm font-bold text-gold-gradient font-display">${maxPrice}</span>
                  <span className="text-xs text-muted-foreground">$500</span>
                </div>
              </div>
            </div>

            {/* Active filter chip */}
            {cat !== "All" && (
              <div className="flex items-center gap-2">
                <span className="glass-gold rounded-full border border-brand/20 px-3 py-1.5 text-xs font-bold text-brand uppercase tracking-widest">
                  {cat}
                </span>
                <button
                  onClick={() => setCat("All")}
                  className="inline-flex h-7 w-7 items-center justify-center rounded-full glass border border-white/8 text-muted-foreground hover:text-foreground hover:border-white/20 transition-all cursor-pointer"
                  aria-label="Clear category filter"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}
          </aside>

          {/* ── Product Grid ── */}
          <div>
            {/* Sort bar */}
            <div className="mb-8 flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm text-muted-foreground font-sans">
                <span className="text-brand font-bold">{filtered.length}</span> products
              </p>
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as Sort)}
                className="rounded-full border border-white/8 glass bg-transparent px-5 py-2.5 text-sm text-foreground focus:outline-none focus:border-brand/40 transition-all cursor-pointer"
                aria-label="Sort products"
              >
                {["Featured", "New Arrivals", "Price: Low to High", "Price: High to Low"].map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            {isLoading ? (
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="aspect-[4/5] animate-pulse rounded-2xl"
                    style={{ background: "rgba(212,169,41,0.04)" }} />
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <div className="glass rounded-2xl border border-white/6 py-20 text-center">
                <p className="text-muted-foreground font-sans text-sm">No products match your filters.</p>
                <button
                  onClick={() => { setCat("All"); setMaxPrice(500); }}
                  className="mt-4 inline-flex items-center rounded-full bg-brand/10 border border-brand/20 px-5 py-2 text-sm text-brand hover:bg-brand/15 transition-all cursor-pointer"
                >
                  Clear filters
                </button>
              </div>
            ) : (
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {filtered.map((p) => <ProductCard key={p.id} product={p} />)}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
