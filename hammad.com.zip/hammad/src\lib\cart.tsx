import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Product } from "./products";

interface CartItem { id: string; qty: number }
interface CartCtx {
  items: CartItem[];
  count: number;
  total: number;
  detailed: { product: Product; qty: number }[];
  loading: boolean;
  add: (id: string, qty?: number) => void;
  remove: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  clear: () => void;
  open: boolean;
  setOpen: (v: boolean) => void;
}

const Ctx = createContext<CartCtx | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("hammad-cart");
      if (raw) setItems(JSON.parse(raw));
    } catch {}
  }, []);
  useEffect(() => {
    try { localStorage.setItem("hammad-cart", JSON.stringify(items)); } catch {}
  }, [items]);

  const ids = items.map((i) => i.id);
  const idsKey = ids.slice().sort().join(",");

  const { data: cartProducts, isLoading } = useQuery({
    queryKey: ["cart-products", idsKey],
    enabled: ids.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("*").in("id", ids);
      if (error) throw error;
      return (data ?? []) as Product[];
    },
  });

  const add = useCallback((id: string, qty = 1) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.id === id);
      if (existing) return prev.map((i) => i.id === id ? { ...i, qty: i.qty + qty } : i);
      return [...prev, { id, qty }];
    });
    setOpen(true);
  }, []);
  const remove = useCallback((id: string) => setItems((p) => p.filter((i) => i.id !== id)), []);
  const setQty = useCallback((id: string, qty: number) => {
    if (qty <= 0) return remove(id);
    setItems((p) => p.map((i) => i.id === id ? { ...i, qty } : i));
  }, [remove]);
  const clear = useCallback(() => setItems([]), []);

  const detailed = useMemo(() => {
    if (!cartProducts) return [];
    return items
      .map((i) => {
        const product = cartProducts.find((p) => p.id === i.id);
        return product ? { product, qty: i.qty } : null;
      })
      .filter((x): x is { product: Product; qty: number } => x !== null);
  }, [items, cartProducts]);

  const count = items.reduce((s, i) => s + i.qty, 0);
  const total = detailed.reduce((s, { product, qty }) => s + Number(product.price) * qty, 0);

  return (
    <Ctx.Provider value={{ items, count, total, detailed, loading: isLoading, add, remove, setQty, clear, open, setOpen }}>
      {children}
    </Ctx.Provider>
  );
}

export const useCart = () => {
  const v = useContext(Ctx);
  if (!v) throw new Error("useCart must be inside CartProvider");
  return v;
};
