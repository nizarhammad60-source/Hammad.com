/**
 * MagneticCursor.tsx
 * Custom cursor: outer ring follows with lag, inner dot snaps instantly.
 * Elements with data-cursor="magnet" attract the cursor toward their center.
 * Elements with data-cursor="text"  expand cursor to a text label.
 */
import { useEffect, useRef } from "react";
import gsap from "gsap";

export function MagneticCursor() {
  const ringRef  = useRef<HTMLDivElement>(null);
  const dotRef   = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const ring  = ringRef.current!;
    const dot   = dotRef.current!;
    const label = labelRef.current!;
    if (!ring || !dot) return;

    let mouseX = window.innerWidth  / 2;
    let mouseY = window.innerHeight / 2;

    /* Smooth ring follower */
    const ringSetX = gsap.quickTo(ring, "x", { duration: 0.55, ease: "power3.out" });
    const ringSetY = gsap.quickTo(ring, "y", { duration: 0.55, ease: "power3.out" });
    /* Snappy dot */
    const dotSetX  = gsap.quickTo(dot, "x", { duration: 0.12, ease: "power2.out" });
    const dotSetY  = gsap.quickTo(dot, "y", { duration: 0.12, ease: "power2.out" });

    const onMove = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      ringSetX(mouseX);
      ringSetY(mouseY);
      dotSetX(mouseX);
      dotSetY(mouseY);
    };

    const onEnter = (e: MouseEvent) => {
      const el = (e.target as HTMLElement).closest("[data-cursor]") as HTMLElement;
      if (!el) return;
      const type = el.dataset.cursor;

      if (type === "magnet") {
        gsap.to(ring, { scale: 1.8, borderColor: "#D4A929", duration: 0.3 });
        gsap.to(dot,  { scale: 0,   duration: 0.2 });
      }
      if (type === "text") {
        const txt = el.dataset.cursorLabel ?? "View";
        label.textContent = txt;
        gsap.to(ring, { scale: 3.5, background: "rgba(212,169,41,.18)", borderColor: "rgba(212,169,41,.5)", duration: 0.35 });
        gsap.to(dot,  { scale: 0, duration: 0.2 });
        gsap.to(label, { opacity: 1, duration: 0.25 });
      }
    };

    const onLeave = (e: MouseEvent) => {
      const el = (e.target as HTMLElement).closest("[data-cursor]");
      if (!el) return;
      gsap.to(ring,  { scale: 1, background: "transparent", borderColor: "rgba(255,255,255,.35)", duration: 0.35 });
      gsap.to(dot,   { scale: 1, duration: 0.2 });
      gsap.to(label, { opacity: 0, duration: 0.2 });
    };

    window.addEventListener("mousemove",   onMove,  { passive: true });
    document.addEventListener("mouseenter", onEnter, true);
    document.addEventListener("mouseleave", onLeave, true);

    /* Hide default cursor */
    document.documentElement.style.cursor = "none";

    return () => {
      window.removeEventListener("mousemove",   onMove);
      document.removeEventListener("mouseenter", onEnter, true);
      document.removeEventListener("mouseleave", onLeave, true);
      document.documentElement.style.cursor = "";
    };
  }, []);

  return (
    <>
      {/* Outer ring */}
      <div
        ref={ringRef}
        aria-hidden="true"
        style={{
          position: "fixed", top: -20, left: -20,
          width: 40, height: 40,
          border: "1.5px solid rgba(255,255,255,.35)",
          borderRadius: "50%",
          pointerEvents: "none",
          zIndex: 9999,
          display: "flex", alignItems: "center", justifyContent: "center",
          mixBlendMode: "difference",
          willChange: "transform",
        }}
      >
        <span
          ref={labelRef}
          style={{
            fontSize: "9px", fontFamily: "'Barlow', sans-serif",
            fontWeight: 700, letterSpacing: "0.12em",
            textTransform: "uppercase", color: "#fff",
            opacity: 0, whiteSpace: "nowrap",
          }}
        />
      </div>

      {/* Inner dot */}
      <div
        ref={dotRef}
        aria-hidden="true"
        style={{
          position: "fixed", top: -3, left: -3,
          width: 6, height: 6,
          background: "#D4A929",
          borderRadius: "50%",
          pointerEvents: "none",
          zIndex: 10000,
          willChange: "transform",
        }}
      />
    </>
  );
}
