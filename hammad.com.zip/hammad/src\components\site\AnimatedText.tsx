/**
 * AnimatedText.tsx
 * Splits heading text into chars/words and animates them
 * with staggered GSAP reveals triggered by ScrollTrigger.
 */
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
gsap.registerPlugin(ScrollTrigger);

interface AnimatedTextProps {
  text: string;
  tag?: "h1" | "h2" | "h3" | "p" | "span";
  className?: string;
  style?: React.CSSProperties;
  delay?: number;
  stagger?: number;
  /** "chars" or "words" */
  splitBy?: "chars" | "words";
  /** If true, trigger when scrolled into view; false = immediate */
  onScroll?: boolean;
}

export function AnimatedText({
  text, tag: Tag = "h2", className = "", style,
  delay = 0, stagger = 0.03, splitBy = "chars", onScroll = true,
}: AnimatedTextProps) {
  const containerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const units = splitBy === "chars"
      ? text.split("").map(c => c === " " ? " " : c)
      : text.split(" ");

    el.innerHTML = units
      .map(u => `<span class="_su" style="display:inline-block;overflow:hidden;"><span class="_si" style="display:inline-block;transform:translateY(110%) rotate(4deg);">${u}${splitBy === "words" ? "&nbsp;" : ""}</span></span>`)
      .join(splitBy === "chars" ? "" : "");

    const spans = el.querySelectorAll("._si");

    const anim = gsap.to(spans, {
      y: 0,
      rotate: 0,
      duration: 0.9,
      ease: "expo.out",
      stagger,
      delay,
      paused: onScroll,
    });

    let st: ScrollTrigger | null = null;
    if (onScroll) {
      st = ScrollTrigger.create({
        trigger: el,
        start: "top 88%",
        onEnter: () => anim.play(),
        once: true,
      });
    }

    return () => {
      anim.kill();
      st?.kill();
    };
  }, [text, delay, stagger, splitBy, onScroll]);

  return (
    <Tag
      ref={containerRef as React.RefObject<any>}
      className={className}
      style={style}
      aria-label={text}
    />
  );
}

/* ── Magnetic Button ────────────────────────────────── */
interface MagneticBtnProps extends React.HTMLAttributes<HTMLElement> {
  as?: "button" | "a";
  href?: string;
  onClick?: () => void;
  children: React.ReactNode;
  variant?: "gold" | "ghost";
}

export function MagneticBtn({
  as: As = "button", children, variant = "gold",
  className = "", style, ...rest
}: MagneticBtnProps) {
  const btnRef   = useRef<HTMLElement>(null);
  const innerRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const btn   = btnRef.current;
    const inner = innerRef.current;
    if (!btn || !inner) return;

    const setX = gsap.quickTo(btn,   "x", { duration: 0.4, ease: "power3.out" });
    const setY = gsap.quickTo(btn,   "y", { duration: 0.4, ease: "power3.out" });
    const iX   = gsap.quickTo(inner, "x", { duration: 0.25, ease: "power3.out" });
    const iY   = gsap.quickTo(inner, "y", { duration: 0.25, ease: "power3.out" });

    const STRENGTH = 0.35;

    const onMove = (e: MouseEvent) => {
      const r  = btn.getBoundingClientRect();
      const cx = r.left + r.width  / 2;
      const cy = r.top  + r.height / 2;
      const dx = (e.clientX - cx) * STRENGTH;
      const dy = (e.clientY - cy) * STRENGTH;
      setX(dx); setY(dy);
      iX(dx * 0.5); iY(dy * 0.5);
    };

    const onLeave = () => {
      setX(0); setY(0); iX(0); iY(0);
    };

    btn.addEventListener("mousemove", onMove);
    btn.addEventListener("mouseleave", onLeave);
    return () => {
      btn.removeEventListener("mousemove", onMove);
      btn.removeEventListener("mouseleave", onLeave);
    };
  }, []);

  const goldStyle: React.CSSProperties = {
    display: "inline-flex", alignItems: "center", justifyContent: "center",
    height: "58px", paddingInline: "2.8rem", borderRadius: "100px",
    background: "linear-gradient(135deg, #D4A929, #F5D060, #C49020)",
    color: "#080706", fontFamily: "'Barlow Condensed', sans-serif",
    fontWeight: 800, fontSize: "13px", letterSpacing: "0.22em",
    textTransform: "uppercase" as const, textDecoration: "none",
    border: "none", cursor: "none",
    boxShadow: "0 8px 50px rgba(212,169,41,.38), 0 0 0 1px rgba(212,169,41,.55)",
    willChange: "transform",
  };
  const ghostStyle: React.CSSProperties = {
    display: "inline-flex", alignItems: "center", justifyContent: "center",
    height: "58px", paddingInline: "2.5rem", borderRadius: "100px",
    background: "rgba(255,255,255,.07)",
    border: "1px solid rgba(255,255,255,.22)",
    backdropFilter: "blur(20px)",
    color: "#fff", fontFamily: "'Barlow', sans-serif",
    fontWeight: 500, fontSize: "14px",
    textDecoration: "none", cursor: "none",
    willChange: "transform",
  };

  return (
    <As
      ref={btnRef as React.RefObject<any>}
      data-cursor="magnet"
      style={{ ...(variant === "gold" ? goldStyle : ghostStyle), ...style }}
      className={className}
      {...rest}
    >
      <span ref={innerRef} style={{ display: "flex", alignItems: "center", gap: "10px" }}>
        {children}
      </span>
    </As>
  );
}
