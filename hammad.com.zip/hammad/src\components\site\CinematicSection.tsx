/**
 * CinematicSection.tsx
 * ─────────────────────────────────────────────────────────────────
 * React wrapper around CinematicVideoPlayer.
 *
 * Interaction chain:
 *   1. Component mounts → CinematicVideoPlayer.create() runs async:
 *      - Extracts N frames from <video> seek+draw
 *      - Uploads all textures to GPU VRAM
 *      - Builds WebGL mesh with custom shader
 *      - Starts 60fps physics loop
 *
 *   2. GSAP ScrollTrigger fires onUpdate:
 *      - player.setProgress(progress) → physics.setTarget(frame)
 *      - Physics engine decelerates toward target with inertia
 *      - Each RAF: shader blends frame[floor] + frame[ceil]
 *        with motion blur proportional to |velocity|
 *
 *   3. On unmount: player.destroy() — frees all VRAM
 * ─────────────────────────────────────────────────────────────────
 */
import { useEffect, useRef, useState, useCallback } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { CinematicVideoPlayer } from "@/engine/CinematicVideoPlayer";

gsap.registerPlugin(ScrollTrigger);

interface CinematicSectionProps {
  /** Video source URL */
  src: string;
  /** Poster image shown during loading */
  poster?: string;
  /** Number of frames to extract. Default: 90 */
  frameCount?: number;
  /** CSS height of the pinned scroll zone. Default: "350vh" */
  scrollHeight?: string;
  /** Children rendered as overlay above the canvas */
  children?: React.ReactNode;
  /** Called when engine is ready */
  onReady?: () => void;
}

type LoadState = "idle" | "extracting" | "ready" | "error";

export function CinematicSection({
  src, poster, frameCount = 90,
  scrollHeight = "350vh", children, onReady,
}: CinematicSectionProps) {

  const wrapRef    = useRef<HTMLDivElement>(null);
  const stickyRef  = useRef<HTMLDivElement>(null);
  const canvasRef  = useRef<HTMLCanvasElement>(null);
  const playerRef  = useRef<CinematicVideoPlayer | null>(null);

  const [loadState,  setLoadState]  = useState<LoadState>("idle");
  const [progress,   setProgress]   = useState(0);

  /* ── Initialise engine ─────────────────────────────────────────── */
  const init = useCallback(async () => {
    const canvas = canvasRef.current;
    if (!canvas || playerRef.current) return;

    try {
      setLoadState("extracting");

      /* Size canvas to viewport */
      canvas.width  = window.innerWidth;
      canvas.height = window.innerHeight;

      const player = await CinematicVideoPlayer.create(
        canvas,
        src,
        {
          frameCount,
          jpegQuality:  0.88,
          blurScale:    0.22,
          onProgress:   p => setProgress(Math.round(p * 100)),
        },
      );

      playerRef.current = player;
      setLoadState("ready");
      onReady?.();

      /* ── Wire up GSAP ScrollTrigger ─────────────────────────────
       * scrub: true = real-time, no lag
       * The physics engine provides its OWN lag via inertia —
       * so ScrollTrigger should report instantly, physics smooths
       * ─────────────────────────────────────────────────────────── */
      ScrollTrigger.create({
        trigger:  wrapRef.current!,
        start:    "top top",
        end:      `+=${scrollHeight}`,
        scrub:    true,
        pin:      stickyRef.current!,
        anticipatePin: 1,
        invalidateOnRefresh: true,
        onUpdate: self => {
          player.setProgress(self.progress);
        },
      });

      /* Resize observer */
      const ro = new ResizeObserver(() => {
        const w = window.innerWidth;
        const h = window.innerHeight;
        canvas.width  = w;
        canvas.height = h;
        player.resize(w, h);
        ScrollTrigger.refresh();
      });
      ro.observe(document.body);

    } catch (err) {
      console.error("CinematicSection:", err);
      setLoadState("error");
    }
  }, [src, frameCount, scrollHeight, onReady]);

  useEffect(() => {
    /* Defer init so DOM is painted */
    const id = setTimeout(init, 120);
    return () => {
      clearTimeout(id);
      playerRef.current?.destroy();
      playerRef.current = null;
      ScrollTrigger.getAll().forEach(t => t.kill());
    };
  }, [init]);

  /* ── Render ─────────────────────────────────────────────────────── */
  return (
    <div ref={wrapRef} style={{ position: "relative", height: scrollHeight }}>

      {/* Sticky frame — stays in view while user scrolls through wrapRef */}
      <div
        ref={stickyRef}
        style={{
          position: "sticky", top: 0,
          width: "100vw", height: "100vh",
          overflow: "hidden",
        }}
      >
        {/* WebGL canvas — full bleed */}
        <canvas
          ref={canvasRef}
          style={{
            position: "absolute", inset: 0,
            width: "100%", height: "100%",
            display: "block",
          }}
          aria-hidden="true"
        />

        {/* Poster / fallback while extracting */}
        {loadState !== "ready" && poster && (
          <img
            src={poster}
            alt=""
            aria-hidden="true"
            style={{
              position: "absolute", inset: 0,
              width: "100%", height: "100%",
              objectFit: "cover",
              filter: "brightness(0.5)",
              transition: "opacity 0.6s",
              opacity: loadState === "extracting" ? 0.6 : 1,
            }}
          />
        )}

        {/* Loading UI */}
        {loadState === "extracting" && (
          <div style={{
            position: "absolute", bottom: "8%", left: "50%",
            transform: "translateX(-50%)", zIndex: 30,
            textAlign: "center", pointerEvents: "none",
          }}>
            {/* Progress bar */}
            <div style={{
              width: "200px", height: "1px",
              background: "rgba(255,255,255,0.12)",
              borderRadius: "1px", overflow: "hidden",
              margin: "0 auto 12px",
            }}>
              <div style={{
                height: "100%", width: `${progress}%`,
                background: "linear-gradient(90deg, #D4A929, #F5D060)",
                transition: "width 0.1s linear",
                boxShadow: "0 0 8px rgba(212,169,41,0.6)",
              }}/>
            </div>
            <p style={{
              fontFamily: "'Barlow', sans-serif", fontSize: "10px",
              letterSpacing: "0.3em", textTransform: "uppercase",
              color: "rgba(255,255,255,0.4)",
            }}>
              Uploading to GPU — {progress}%
            </p>
          </div>
        )}

        {/* Error fallback */}
        {loadState === "error" && (
          <div style={{
            position: "absolute", inset: 0, display: "flex",
            alignItems: "center", justifyContent: "center",
            background: "#080706",
          }}>
            <p style={{ color: "rgba(255,255,255,0.3)", fontFamily: "'Barlow', sans-serif", fontSize: "12px" }}>
              WebGL unavailable on this device.
            </p>
          </div>
        )}

        {/* Overlay: letterbox + grain + vignette + content */}
        {loadState === "ready" && (
          <>
            {/* Letterbox */}
            <div style={{ position:"absolute", inset:0, zIndex:10, pointerEvents:"none",
              boxShadow:"inset 0 12vh 0 #000, inset 0 -12vh 0 #000" }}/>

            {/* Film grain */}
            <div aria-hidden="true" style={{
              position:"absolute", inset:0, zIndex:11, pointerEvents:"none", opacity:0.04,
              backgroundImage:`url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='g'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.82' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23g)'/%3E%3C/svg%3E")`,
              backgroundSize:"256px 256px",
            }}/>

            {/* Gradient overlay */}
            <div style={{ position:"absolute", inset:0, zIndex:12, pointerEvents:"none",
              background:"linear-gradient(180deg,rgba(0,0,0,.45) 0%,rgba(0,0,0,.02) 20%,rgba(0,0,0,.02) 70%,rgba(0,0,0,.72) 100%)" }}/>

            {/* Content slot */}
            {children && (
              <div style={{ position:"absolute", inset:0, zIndex:20 }}>
                {children}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
