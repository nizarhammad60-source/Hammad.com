import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Package, DollarSign, Tag, TrendingUp, Plus, Pencil, Trash2, X, LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useProducts, productsQueryKey } from "@/lib/queries";
import { CATEGORIES, type Product } from "@/lib/products";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Dashboard — HAMMAD" }] }),
  component: AdminPage,
});

interface FormState {
  id?: string;
  name: string;
  category: string;
  price: string;
  description: string;
  long_description: string;
  image_url: string;
  badge: string;
  featured: boolean;
  stock: string;
}

const emptyForm: FormState = {
  name: "", category: CATEGORIES[0], price: "", description: "",
  long_description: "", image_url: "", badge: "", featured: false, stock: "0",
};

function AdminPage() {
  const { data: products = [], isLoading } = useProducts();
  const qc = useQueryClient();
  const { user, signOut } = useAuth();
  const [editing, setEditing] = useState<FormState | null>(null);
  const [saving, setSaving] = useState(false);

  const stats = useMemo(() => {
    const totalValue = products.reduce((s, p) => s + Number(p.price) * p.stock, 0);
    const featuredCount = products.filter((p) => p.featured).length;
    const byCat: Record<string, number> = {};
    products.forEach((p) => { byCat[p.category] = (byCat[p.category] ?? 0) + 1; });
    const topCat = Object.entries(byCat).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "—";
    return { total: products.length, totalValue, featuredCount, topCat };
  }, [products]);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing) return;
    setSaving(true);
    const payload = {
      name: editing.name.trim(),
      category: editing.category,
      price: Number(editing.price),
      description: editing.description.trim(),
      long_description: editing.long_description.trim(),
      image_url: editing.image_url.trim(),
      badge: editing.badge.trim() || null,
      featured: editing.featured,
      stock: Number(editing.stock) || 0,
    };
    const { error } = editing.id
      ? await supabase.from("products").update(payload).eq("id", editing.id)
      : await supabase.from("products").insert(payload);
    setSaving(false);
    if (error) { alert(error.message); return; }
    qc.invalidateQueries({ queryKey: productsQueryKey });
    setEditing(null);
  };

  const remove = async (p: Product) => {
    if (!confirm(`Delete "${p.name}"?`)) return;
    const { error } = await supabase.from("products").delete().eq("id", p.id);
    if (error) { alert(error.message); return; }
    qc.invalidateQueries({ queryKey: productsQueryKey });
  };

  const startEdit = (p: Product) => setEditing({
    id: p.id, name: p.name, category: p.category, price: String(p.price),
    description: p.description, long_description: p.long_description,
    image_url: p.image_url, badge: p.badge ?? "", featured: p.featured, stock: String(p.stock),
  });

  return (
    <div className="container-x py-12">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Dashboard</p>
          <h1 className="mt-2 font-display text-4xl md:text-5xl tracking-tight">Welcome back</h1>
          <p className="mt-2 text-sm text-muted-foreground">Signed in as {user?.email}</p>
        </div>
        <div className="flex gap-2">
          <Link to="/" className="rounded-full border border-border px-4 py-2 text-xs hover:bg-secondary">View store</Link>
          <button onClick={signOut} className="inline-flex items-center gap-1.5 rounded-full border border-border px-4 py-2 text-xs hover:bg-secondary">
            <LogOut className="h-3.5 w-3.5" /> Sign out
          </button>
        </div>
      </div>

      {/* STATS */}
      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { icon: Package, label: "Total products", value: stats.total },
          { icon: DollarSign, label: "Inventory value", value: `$${stats.totalValue.toFixed(0)}` },
          { icon: TrendingUp, label: "Featured", value: stats.featuredCount },
          { icon: Tag, label: "Top category", value: stats.topCat },
        ].map(({ icon: Icon, label, value }) => (
          <div key={label} className="rounded-2xl bg-card p-6 ring-1 ring-border/60">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-widest text-muted-foreground">{label}</span>
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary"><Icon className="h-4 w-4" /></span>
            </div>
            <p className="mt-3 font-display text-3xl">{value}</p>
          </div>
        ))}
      </div>

      {/* CATEGORY BREAKDOWN */}
      <div className="mt-6 rounded-2xl bg-card p-6 ring-1 ring-border/60">
        <h2 className="font-display text-xl">By category</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {CATEGORIES.map((c) => {
            const count = products.filter((p) => p.category === c).length;
            const pct = stats.total > 0 ? (count / stats.total) * 100 : 0;
            return (
              <div key={c}>
                <div className="flex items-baseline justify-between"><span className="text-xs text-muted-foreground">{c}</span><span className="text-sm font-medium">{count}</span></div>
                <div className="mt-2 h-1.5 rounded-full bg-secondary overflow-hidden"><div className="h-full bg-brand transition-all" style={{ width: `${pct}%` }} /></div>
              </div>
            );
          })}
        </div>
      </div>

      {/* PRODUCT TABLE */}
      <div className="mt-10 flex items-end justify-between">
        <h2 className="font-display text-2xl">Products</h2>
        <button
          onClick={() => setEditing({ ...emptyForm })}
          className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm text-primary-foreground hover:opacity-90"
        >
          <Plus className="h-4 w-4" /> Add product
        </button>
      </div>

      <div className="mt-4 overflow-hidden rounded-2xl bg-card ring-1 ring-border/60">
        {isLoading ? (
          <p className="p-10 text-center text-sm text-muted-foreground">Loading…</p>
        ) : products.length === 0 ? (
          <p className="p-10 text-center text-sm text-muted-foreground">No products yet. Click "Add product" to create your first.</p>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-secondary/60 text-xs uppercase tracking-widest text-muted-foreground">
              <tr>
                <th className="px-4 py-3 text-left">Product</th>
                <th className="px-4 py-3 text-left hidden md:table-cell">Category</th>
                <th className="px-4 py-3 text-left">Price</th>
                <th className="px-4 py-3 text-left hidden sm:table-cell">Stock</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id} className="border-t border-border/60">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      {p.image_url ? <img src={p.image_url} alt="" className="h-10 w-10 rounded-md object-cover bg-secondary" /> : <div className="h-10 w-10 rounded-md bg-secondary" />}
                      <div>
                        <p className="font-medium">{p.name}</p>
                        {p.featured && <span className="text-[10px] uppercase tracking-widest text-brand">Featured</span>}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{p.category}</td>
                  <td className="px-4 py-3">${Number(p.price).toFixed(2)}</td>
                  <td className="px-4 py-3 hidden sm:table-cell">{p.stock}</td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => startEdit(p)} className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs hover:bg-secondary"><Pencil className="h-3 w-3" /> Edit</button>
                    <button onClick={() => remove(p)} className="ml-1 inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs text-destructive hover:bg-secondary"><Trash2 className="h-3 w-3" /> Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* FORM MODAL */}
      {editing && (
        <>
          <div className="fixed inset-0 z-50 bg-foreground/40 backdrop-blur-sm" onClick={() => setEditing(null)} />
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none">
            <form
              onSubmit={save}
              className="pointer-events-auto w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-card p-8 shadow-2xl ring-1 ring-border/60"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-display text-2xl">{editing.id ? "Edit product" : "New product"}</h3>
                <button type="button" onClick={() => setEditing(null)} className="rounded-full p-2 hover:bg-secondary"><X className="h-4 w-4" /></button>
              </div>
              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                <Field label="Name" className="sm:col-span-2"><input required value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} className={inputCls} /></Field>
                <Field label="Category"><select value={editing.category} onChange={(e) => setEditing({ ...editing, category: e.target.value })} className={inputCls}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></Field>
                <Field label="Price (USD)"><input required type="number" step="0.01" min="0" value={editing.price} onChange={(e) => setEditing({ ...editing, price: e.target.value })} className={inputCls} /></Field>
                <Field label="Stock"><input type="number" min="0" value={editing.stock} onChange={(e) => setEditing({ ...editing, stock: e.target.value })} className={inputCls} /></Field>
                <Field label="Badge (optional)"><input placeholder="New / Best Seller / Sale" value={editing.badge} onChange={(e) => setEditing({ ...editing, badge: e.target.value })} className={inputCls} /></Field>
                <Field label="Image URL" className="sm:col-span-2"><input placeholder="https://…" value={editing.image_url} onChange={(e) => setEditing({ ...editing, image_url: e.target.value })} className={inputCls} /></Field>
                <Field label="Short description" className="sm:col-span-2"><input value={editing.description} onChange={(e) => setEditing({ ...editing, description: e.target.value })} className={inputCls} /></Field>
                <Field label="Long description" className="sm:col-span-2"><textarea rows={4} value={editing.long_description} onChange={(e) => setEditing({ ...editing, long_description: e.target.value })} className={inputCls} /></Field>
                <label className="sm:col-span-2 flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={editing.featured} onChange={(e) => setEditing({ ...editing, featured: e.target.checked })} className="h-4 w-4 accent-brand" />
                  Feature on the homepage
                </label>
              </div>
              <div className="mt-8 flex justify-end gap-2">
                <button type="button" onClick={() => setEditing(null)} className="rounded-full border border-border px-5 py-2.5 text-sm hover:bg-secondary">Cancel</button>
                <button type="submit" disabled={saving} className="rounded-full bg-primary px-6 py-2.5 text-sm text-primary-foreground hover:opacity-90 disabled:opacity-60">
                  {saving ? "Saving…" : editing.id ? "Save changes" : "Create product"}
                </button>
              </div>
            </form>
          </div>
        </>
      )}
    </div>
  );
}

const inputCls = "w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring";

function Field({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="block text-xs font-medium uppercase tracking-widest text-muted-foreground">{label}</span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}
