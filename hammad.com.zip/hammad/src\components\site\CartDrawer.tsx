import { X, Minus, Plus, Trash2, ShoppingBag, ArrowRight, Zap } from "lucide-react";
import { useCart } from "@/lib/cart";
import { Link } from "@tanstack/react-router";

export function CartDrawer() {
  const { open, setOpen, detailed, setQty, remove, total, clear } = useCart();

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 z-50 transition-all duration-500 ${
          open ? "opacity-100 pointer-events-auto" : "pointer-events-none opacity-0"
        }`}
        style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(8px)" }}
        onClick={() => setOpen(false)}
      />

      {/* Drawer */}
      <aside
        className={`fixed right-0 top-0 z-50 flex h-full w-full max-w-[420px] flex-col transition-transform duration-500 ease-in-out ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
        style={{
          background: "linear-gradient(180deg, rgba(14,12,9,0.98) 0%, rgba(8,7,6,0.99) 100%)",
          backdropFilter: "blur(24px)",
          borderLeft: "1px solid rgba(212,169,41,0.1)",
          boxShadow: "-20px 0 60px rgba(0,0,0,0.7)",
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-white/6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full glass-gold border border-brand/20">
              <ShoppingBag className="h-4 w-4 text-brand" />
            </div>
            <div>
              <h3 className="font-display text-lg tracking-wide" style={{ fontWeight: 700 }}>YOUR CART</h3>
              <p className="text-[11px] text-muted-foreground">
                {detailed.length} {detailed.length === 1 ? "item" : "items"}
              </p>
            </div>
          </div>
          <button
            onClick={() => setOpen(false)}
            aria-label="Close cart"
            className="inline-flex h-9 w-9 items-center justify-center rounded-full glass border border-white/8 text-muted-foreground hover:text-foreground hover:border-brand/20 transition-all cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Body */}
        {detailed.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-5 px-6 text-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full glass border border-white/6">
              <ShoppingBag className="h-8 w-8 text-muted-foreground" />
            </div>
            <div>
              <p className="font-display text-xl mb-1" style={{ fontWeight: 700 }}>CART IS EMPTY</p>
              <p className="text-sm text-muted-foreground font-sans">Start adding your favourite gear.</p>
            </div>
            <Link
              to="/products"
              onClick={() => setOpen(false)}
              className="btn-shine inline-flex h-12 items-center gap-2 rounded-full bg-brand px-8 text-sm font-bold uppercase tracking-widest text-brand-foreground hover:opacity-90 cursor-pointer"
            >
              Browse Products <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        ) : (
          <>
            {/* Items */}
            <div className="flex-1 overflow-y-auto px-5 py-5 space-y-4">
              {detailed.map(({ product, qty }) => (
                <div key={product.id}
                  className="group flex gap-4 glass rounded-2xl border border-white/5 p-4 hover:border-brand/15 transition-all duration-300">
                  {/* Image */}
                  <div className="h-20 w-20 rounded-xl overflow-hidden shrink-0 bg-secondary border border-white/5">
                    {product.image_url ? (
                      <img src={product.image_url} alt={product.name} className="h-full w-full object-cover" />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center text-xs text-muted-foreground">—</div>
                    )}
                  </div>

                  {/* Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <p className="text-sm font-semibold text-foreground truncate leading-tight">{product.name}</p>
                      <button
                        onClick={() => remove(product.id)}
                        aria-label={`Remove ${product.name}`}
                        className="text-muted-foreground hover:text-destructive transition-colors flex-shrink-0 cursor-pointer mt-0.5"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <p className="text-[10px] text-brand uppercase tracking-widest font-bold mb-3">{product.category}</p>

                    <div className="flex items-center justify-between">
                      {/* Qty controls */}
                      <div className="inline-flex items-center glass rounded-full border border-white/8">
                        <button
                          onClick={() => setQty(product.id, qty - 1)}
                          className="flex h-7 w-7 items-center justify-center text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
                          aria-label="Decrease"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="w-7 text-center text-xs font-semibold">{qty}</span>
                        <button
                          onClick={() => setQty(product.id, qty + 1)}
                          className="flex h-7 w-7 items-center justify-center text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
                          aria-label="Increase"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                      {/* Line total */}
                      <p className="font-display text-base text-gold-gradient" style={{ fontWeight: 700 }}>
                        ${(Number(product.price) * qty).toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="border-t border-white/6 px-5 py-5 space-y-4"
              style={{ background: "rgba(10,8,6,0.9)" }}>
              {/* Free shipping notice */}
              <div className="glass-gold rounded-xl border border-brand/12 px-4 py-2.5 flex items-center gap-2">
                <Zap className="h-3.5 w-3.5 text-brand flex-shrink-0" />
                <p className="text-[11px] text-brand font-semibold">Free express shipping on this order</p>
              </div>

              {/* Subtotal */}
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground font-sans">Subtotal</span>
                <span className="font-display text-2xl text-gold-gradient" style={{ fontWeight: 800 }}>
                  ${total.toFixed(2)}
                </span>
              </div>

              {/* Checkout */}
              <button className="btn-shine w-full rounded-full bg-brand py-4 text-sm font-bold uppercase tracking-widest text-brand-foreground hover:opacity-90 transition-opacity cursor-pointer">
                Checkout Now
              </button>

              {/* Clear */}
              <button
                onClick={clear}
                className="w-full text-center text-xs text-muted-foreground hover:text-foreground transition-colors py-1 cursor-pointer"
              >
                Clear cart
              </button>
            </div>
          </>
        )}
      </aside>
    </>
  );
}
