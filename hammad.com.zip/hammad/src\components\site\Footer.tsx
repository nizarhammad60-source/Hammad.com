import { Link } from "@tanstack/react-router";
import { Instagram, Twitter, Youtube, Mail, ArrowUpRight, Zap } from "lucide-react";

const shopLinks = [
  { label: "All Products", to: "/products" },
  { label: "New Arrivals", to: "/products" },
  { label: "Best Sellers", to: "/products" },
  { label: "Training Gear", to: "/products" },
  { label: "Apparel", to: "/products" },
];

const companyLinks = [
  { label: "About HAMMAD", to: "/about" },
  { label: "Contact Us", to: "/about" },
  { label: "Shipping Policy", to: "/about" },
  { label: "Returns", to: "/about" },
];

export function Footer() {
  return (
    <footer className="relative mt-32 overflow-hidden">
      {/* Top divider */}
      <div className="divider-gold" />

      {/* Background glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 80% 40% at 50% 0%, rgba(212,169,41,0.04) 0%, transparent 70%)",
        }}
      />

      {/* ── Newsletter strip ── */}
      <div className="relative border-b border-white/5" style={{ background: "rgba(212,169,41,0.04)" }}>
        <div className="container-x py-12">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <p className="text-xs uppercase tracking-[0.25em] text-brand font-semibold mb-2">Stay Ahead</p>
              <h3 className="font-display text-3xl text-foreground">Join the Inner Circle</h3>
              <p className="mt-1 text-sm text-muted-foreground">Exclusive drops, training tips, early access.</p>
            </div>
            <div className="flex gap-2 max-w-md w-full">
              <input
                type="email"
                placeholder="your@email.com"
                className="flex-1 rounded-full border border-white/8 bg-white/4 px-5 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-brand/40 focus:bg-white/6 transition-all input-gold"
              />
              <button className="btn-shine inline-flex items-center gap-2 rounded-full bg-brand px-6 py-3 text-sm font-semibold text-brand-foreground hover:opacity-90 transition-opacity whitespace-nowrap cursor-pointer">
                Subscribe <Zap className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ── Main footer grid ── */}
      <div className="container-x py-16">
        <div className="grid gap-12 md:grid-cols-12">

          {/* Brand column */}
          <div className="md:col-span-4">
            <Link to="/" className="inline-flex items-baseline gap-1 mb-5">
              <span className="font-display text-4xl tracking-[0.08em] text-gold-gradient" style={{ fontWeight: 800 }}>HAMMAD</span>
              <span className="text-[10px] text-muted-foreground tracking-widest">.COM</span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-xs">
              Premium sports equipment designed for athletes, fitness lovers, and everyday performance. Trusted by champions worldwide.
            </p>

            {/* Social links */}
            <div className="mt-8 flex items-center gap-3">
              {[
                { icon: Instagram, label: "Instagram", href: "#" },
                { icon: Twitter, label: "X / Twitter", href: "#" },
                { icon: Youtube, label: "YouTube", href: "#" },
                { icon: Mail, label: "Email", href: "mailto:support@hammad.com" },
              ].map(({ icon: Icon, label, href }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="inline-flex h-10 w-10 items-center justify-center rounded-full glass border border-white/8 text-muted-foreground hover:text-brand hover:border-brand/30 transition-all duration-300 cursor-pointer"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Shop column */}
          <div className="md:col-span-3 md:col-start-6">
            <h4 className="font-display text-sm tracking-[0.2em] text-brand mb-5">SHOP</h4>
            <ul className="space-y-3">
              {shopLinks.map((l) => (
                <li key={l.label}>
                  <Link
                    to={l.to}
                    className="group inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors duration-200 cursor-pointer"
                  >
                    {l.label}
                    <ArrowUpRight className="h-3 w-3 opacity-0 -translate-y-0.5 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all duration-200" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company column */}
          <div className="md:col-span-3 md:col-start-10">
            <h4 className="font-display text-sm tracking-[0.2em] text-brand mb-5">COMPANY</h4>
            <ul className="space-y-3">
              {companyLinks.map((l) => (
                <li key={l.label}>
                  <Link
                    to={l.to}
                    className="group inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors duration-200 cursor-pointer"
                  >
                    {l.label}
                    <ArrowUpRight className="h-3 w-3 opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all duration-200" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* ── Bottom bar ── */}
        <div className="mt-16 pt-6 divider-gold" />
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
          <p>© {new Date().getFullYear()} HAMMAD Sports. All rights reserved.</p>
          <p className="flex items-center gap-2">
            <span className="h-1 w-1 rounded-full bg-brand inline-block" />
            Crafted for athletes — worldwide shipping.
          </p>
        </div>
      </div>
    </footer>
  );
}
