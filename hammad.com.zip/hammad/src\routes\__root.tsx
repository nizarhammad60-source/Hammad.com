import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { CartProvider } from "@/lib/cart";
import { AuthProvider } from "@/lib/auth";
import { Header }         from "@/components/site/Header";
import { Footer }         from "@/components/site/Footer";
import { CartDrawer }     from "@/components/site/CartDrawer";
import { MagneticCursor } from "@/components/site/MagneticCursor";

function NotFoundComponent() {
  return (
    <div className="relative flex min-h-screen items-center justify-center bg-background px-4 overflow-hidden">
      <div className="orb w-[600px] h-[600px] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
        style={{ background: "radial-gradient(circle, rgba(212,169,41,0.07) 0%, transparent 65%)" }} />
      <div className="relative z-10 max-w-md text-center">
        <p className="font-display text-[10rem] text-gold-gradient leading-none mb-4" style={{ fontWeight: 900, opacity: 0.15 }}>404</p>
        <h1 className="font-display text-5xl tracking-wide mb-4" style={{ fontWeight: 900, marginTop: "-4rem" }}>PAGE NOT FOUND</h1>
        <p className="text-sm text-muted-foreground font-sans mb-8">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <Link to="/"
          className="btn-shine inline-flex h-12 items-center gap-2 rounded-full bg-brand px-8 text-sm font-bold uppercase tracking-widest text-brand-foreground hover:opacity-90 cursor-pointer">
          Go Home
        </Link>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold">This page didn't load</h1>
        <p className="mt-2 text-sm text-muted-foreground">Something went wrong on our end.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => { router.invalidate(); reset(); }}
            className="rounded-full bg-primary px-5 py-2.5 text-sm text-primary-foreground hover:opacity-90"
          >
            Try again
          </button>
          <a href="/" className="rounded-full border border-input bg-background px-5 py-2.5 text-sm hover:bg-secondary">Go home</a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "HAMMAD — Premium Sports Equipment" },
      { name: "description", content: "Premium sports equipment for athletes, fitness lovers, and everyday performance. Shop at HAMMAD." },
      { property: "og:title", content: "HAMMAD — Premium Sports Equipment" },
      { property: "og:description", content: "Premium sports equipment for athletes, fitness lovers, and everyday performance." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "HAMMAD" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@300;400;500;600;700;800;900&family=Barlow:wght@300;400;500;600;700&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <CartProvider>
          <div className="flex min-h-screen flex-col">
            <Header />
            <main className="flex-1">
              <Outlet />
            </main>
            <Footer />
          </div>
          <CartDrawer />
          <MagneticCursor />
        </CartProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}
