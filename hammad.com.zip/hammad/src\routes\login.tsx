import { createFileRoute, redirect } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { z } from "zod";
import { Eye, EyeOff, ArrowRight, Shield } from "lucide-react";

export const Route = createFileRoute("/login")({
  validateSearch: z.object({ redirect: z.string().optional() }),
  head: () => ({ meta: [{ title: "Sign in — HAMMAD Dashboard" }] }),
  component: LoginPage,
});

function LoginPage() {
  const { session } = useAuth();
  const search = Route.useSearch();
  const navigate = Route.useNavigate();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);

  if (session) {
    throw redirect({ to: search.redirect ?? "/admin" });
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(""); setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: {
            emailRedirectTo: `${window.location.origin}/admin`,
            data: { full_name: name },
          },
        });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
      navigate({ to: search.redirect ?? "/admin" });
    } catch (e: any) {
      setErr(e.message ?? "Something went wrong");
    } finally { setLoading(false); }
  };

  return (
    <div className="relative min-h-[85vh] flex items-center justify-center overflow-hidden">
      {/* Ambient */}
      <div className="orb w-[600px] h-[600px] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
        style={{ background: "radial-gradient(circle, rgba(212,169,41,0.07) 0%, transparent 65%)" }} />
      <div className="absolute inset-0 pointer-events-none" style={{
        backgroundImage: `linear-gradient(rgba(212,169,41,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(212,169,41,0.025) 1px, transparent 1px)`,
        backgroundSize: "80px 80px",
      }} />

      <div className="relative z-10 w-full max-w-md px-4 py-16 fade-up">
        {/* Logo */}
        <div className="text-center mb-10">
          <h1 className="font-display text-4xl text-gold-gradient tracking-[0.1em] mb-1" style={{ fontWeight: 900 }}>
            HAMMAD
          </h1>
          <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Dashboard Access</p>
        </div>

        {/* Card */}
        <div className="glass rounded-3xl border border-white/6 p-8"
          style={{
            background: "linear-gradient(145deg, rgba(18,16,12,0.95) 0%, rgba(10,8,6,0.95) 100%)",
            boxShadow: "0 40px 80px rgba(0,0,0,0.5), 0 0 0 1px rgba(212,169,41,0.06)",
          }}>
          {/* Mode tabs */}
          <div className="flex glass rounded-full border border-white/8 p-1 mb-8">
            {(["login", "signup"] as const).map((m) => (
              <button key={m} onClick={() => setMode(m)}
                className={`flex-1 rounded-full py-2.5 text-xs font-bold uppercase tracking-widest transition-all duration-300 cursor-pointer ${
                  mode === m
                    ? "bg-brand text-brand-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}>
                {m === "login" ? "Sign In" : "Create Account"}
              </button>
            ))}
          </div>

          <div className="mb-6">
            <p className="font-display text-xl tracking-wide" style={{ fontWeight: 700 }}>
              {mode === "login" ? "WELCOME BACK" : "JOIN HAMMAD"}
            </p>
            <p className="text-sm text-muted-foreground font-sans mt-1">
              {mode === "login" ? "Sign in to access your dashboard." : "First account becomes the store admin."}
            </p>
          </div>

          <form onSubmit={submit} className="space-y-4">
            {mode === "signup" && (
              <div>
                <label htmlFor="name" className="block text-[10px] font-bold uppercase tracking-[0.2em] text-brand mb-2">Full Name</label>
                <input id="name" type="text" required placeholder="John Doe" value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="input-gold w-full rounded-xl border border-white/8 bg-white/4 px-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none transition-all"
                />
              </div>
            )}

            <div>
              <label htmlFor="email" className="block text-[10px] font-bold uppercase tracking-[0.2em] text-brand mb-2">Email</label>
              <input id="email" type="email" required placeholder="you@example.com" value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input-gold w-full rounded-xl border border-white/8 bg-white/4 px-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none transition-all"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-[10px] font-bold uppercase tracking-[0.2em] text-brand mb-2">Password</label>
              <div className="relative">
                <input id="password" type={showPass ? "text" : "password"} required minLength={6}
                  placeholder="Min 6 characters" value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="input-gold w-full rounded-xl border border-white/8 bg-white/4 px-4 py-3.5 pr-12 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none transition-all"
                />
                <button type="button" onClick={() => setShowPass((s) => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
                  aria-label="Toggle password visibility">
                  {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {err && (
              <div className="glass rounded-xl border border-destructive/30 px-4 py-3">
                <p className="text-xs text-destructive">{err}</p>
              </div>
            )}

            <button type="submit" disabled={loading}
              className="btn-shine w-full rounded-full bg-brand py-4 text-sm font-bold uppercase tracking-widest text-brand-foreground hover:opacity-90 disabled:opacity-60 transition-all cursor-pointer flex items-center justify-center gap-2">
              {loading ? (
                <span className="inline-flex items-center gap-2">
                  <span className="h-4 w-4 border-2 border-brand-foreground/30 border-t-brand-foreground rounded-full animate-spin" />
                  Please wait...
                </span>
              ) : (
                <>
                  {mode === "login" ? "Sign In" : "Create Account"}
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </button>
          </form>

          {/* Security note */}
          <div className="mt-6 flex items-center justify-center gap-2 text-xs text-muted-foreground">
            <Shield className="h-3 w-3 text-brand" />
            <span>Encrypted & secure connection</span>
          </div>
        </div>
      </div>
    </div>
  );
}
