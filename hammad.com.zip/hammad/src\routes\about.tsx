import { createFileRoute } from "@tanstack/react-router";
import { Mail, Phone, MapPin, Send, Target, Gem, Shield, TrendingUp } from "lucide-react";
import { useState } from "react";
import { z } from "zod";
import about from "@/assets/about.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About & Contact — HAMMAD" },
      { name: "description", content: "Learn about HAMMAD — a modern sports brand built for athletes — and get in touch." },
    ],
  }),
  component: AboutPage,
});

const schema = z.object({
  name: z.string().trim().min(2, "Name too short").max(100),
  email: z.string().trim().email("Invalid email").max(255),
  phone: z.string().trim().min(5, "Phone too short").max(30),
  message: z.string().trim().min(10, "Tell us a bit more").max(1000),
});

const PILLARS = [
  { icon: Target, t: "Our Mission", d: "Equip every athlete with gear that performs as quietly and confidently as they do." },
  { icon: Gem, t: "Our Promise", d: "Materials tested in real conditions. Designs refined until nothing extra remains." },
  { icon: Shield, t: "Our Standard", d: "If we wouldn't trust it in our own training, it doesn't carry the HAMMAD mark." },
];

const STATS_ABOUT = [
  { k: "120K+", v: "Athletes served" },
  { k: "48 HRS", v: "Average shipping" },
  { k: "4.9★", v: "Customer rating" },
  { k: "2 YRS", v: "Standard warranty" },
];

function AboutPage() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sent, setSent] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const r = schema.safeParse(form);
    if (!r.success) {
      const fe: Record<string, string> = {};
      r.error.issues.forEach((i) => (fe[i.path[0] as string] = i.message));
      setErrors(fe);
      return;
    }
    setErrors({});
    setSent(true);
    setForm({ name: "", email: "", phone: "", message: "" });
  };

  return (
    <>
      {/* ══ HERO ══ */}
      <section className="relative overflow-hidden">
        {/* Ambient */}
        <div className="orb w-[700px] h-[700px] -top-32 -left-32"
          style={{ background: "radial-gradient(circle, rgba(212,169,41,0.08) 0%, transparent 65%)" }} />
        <div className="absolute inset-0 pointer-events-none" style={{
          backgroundImage: `linear-gradient(rgba(212,169,41,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(212,169,41,0.025) 1px, transparent 1px)`,
          backgroundSize: "80px 80px",
        }} />

        <div className="container-x pt-16 pb-20 md:pt-24">
          <div className="grid gap-14 lg:grid-cols-2 lg:gap-20 items-center">
            <div className="flex flex-col justify-center fade-up">
              <p className="text-[11px] uppercase tracking-[0.3em] text-brand font-bold mb-5">About HAMMAD</p>
              <h1 className="font-display leading-[0.9] tracking-[0.02em] text-balance"
                style={{ fontSize: "clamp(3rem, 6vw, 5.5rem)", fontWeight: 900 }}>
                A MODERN BRAND BUILT FOR EVERY ATHLETE.
              </h1>
              <p className="mt-7 text-base text-muted-foreground leading-relaxed max-w-lg font-sans">
                HAMMAD is a modern sports equipment brand built to provide reliable, stylish, and
                high-performance gear for every athlete — from the morning runner to the championship competitor.
              </p>

              <div className="mt-10 flex items-center gap-4">
                <div className="h-px flex-1 bg-gradient-to-r from-brand/40 to-transparent" />
                <span className="text-xs uppercase tracking-[0.2em] text-brand font-bold">Est. Palestine</span>
                <div className="h-px flex-1 bg-gradient-to-l from-brand/40 to-transparent" />
              </div>
            </div>

            <div className="relative aspect-[5/4] overflow-hidden rounded-3xl fade-up" style={{
              animationDelay: "0.15s",
              boxShadow: "0 40px 100px rgba(0,0,0,0.7), 0 0 0 1px rgba(212,169,41,0.1)",
            }}>
              <div className="absolute inset-0 z-10 bg-gradient-to-br from-brand/6 via-transparent to-transparent pointer-events-none" />
              <img src={about} alt="HAMMAD training space" loading="lazy" className="h-full w-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* ══ PILLARS ══ */}
      <section className="container-x py-20">
        <div className="grid gap-5 md:grid-cols-3">
          {PILLARS.map(({ icon: Icon, t, d }, i) => (
            <div key={t}
              className="glass-gold rounded-2xl border border-brand/10 p-8 hover:border-brand/25 transition-all duration-300 fade-up"
              style={{ animationDelay: `${i * 0.1}s` }}>
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl glass rounded-xl mb-5 border border-white/8">
                <Icon className="h-5 w-5 text-brand" />
              </div>
              <h3 className="font-display text-xl tracking-wide text-foreground mb-3" style={{ fontWeight: 700 }}>
                {t.toUpperCase()}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed font-sans">{d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ══ STATS ══ */}
      <section className="container-x py-10 mb-8">
        <div className="relative overflow-hidden rounded-3xl border border-white/6 p-10 md:p-16"
          style={{ background: "linear-gradient(135deg, rgba(18,16,12,1) 0%, rgba(8,7,6,1) 100%)" }}>
          <div className="absolute inset-0 pointer-events-none"
            style={{ background: "radial-gradient(ellipse 60% 50% at 50% 0%, rgba(212,169,41,0.05) 0%, transparent 70%)" }} />
          <div className="relative z-10 grid gap-8 md:grid-cols-4">
            {STATS_ABOUT.map(({ k, v }) => (
              <div key={v} className="text-center md:text-left">
                <p className="font-display text-gold-gradient leading-none mb-2"
                  style={{ fontSize: "clamp(2rem, 4vw, 3rem)", fontWeight: 900 }}>{k}</p>
                <p className="text-sm text-muted-foreground font-sans">{v}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ CONTACT ══ */}
      <section className="container-x py-20 pb-10">
        <div className="mb-14 text-center max-w-xl mx-auto">
          <p className="text-[11px] uppercase tracking-[0.3em] text-brand font-bold mb-3">Contact</p>
          <h2 className="font-display leading-none tracking-wide"
            style={{ fontSize: "clamp(2.5rem, 5vw, 4.5rem)", fontWeight: 900 }}>
            LET'S TALK.
          </h2>
          <p className="mt-4 text-muted-foreground font-sans">
            Questions about a product, a bulk order, or a partnership?
            We answer every message within one business day.
          </p>
        </div>

        <div className="grid gap-12 lg:grid-cols-[1fr_1.3fr] lg:gap-16">

          {/* ── Contact Info ── */}
          <div>
            <ul className="space-y-5 mb-8">
              {[
                { icon: Mail, label: "Email", value: "support@hammad.com", href: "mailto:support@hammad.com" },
                { icon: Phone, label: "Phone", value: "+970 59 000 0000", href: "tel:+970590000000" },
                { icon: MapPin, label: "Location", value: "Palestine", href: undefined },
              ].map(({ icon: Icon, label, value, href }) => (
                <li key={label} className="flex items-start gap-4 group">
                  <span className="flex h-11 w-11 items-center justify-center rounded-2xl glass-gold border border-brand/15 flex-shrink-0 group-hover:border-brand/30 transition-all">
                    <Icon className="h-4 w-4 text-brand" />
                  </span>
                  <div>
                    <p className="text-[10px] uppercase tracking-[0.2em] text-brand font-bold">{label}</p>
                    {href ? (
                      <a href={href} className="text-sm font-medium text-foreground hover:text-brand transition-colors mt-0.5 block hover-underline-gold cursor-pointer">
                        {value}
                      </a>
                    ) : (
                      <p className="text-sm font-medium text-foreground mt-0.5">{value}</p>
                    )}
                  </div>
                </li>
              ))}
            </ul>

            {/* Map */}
            <div className="overflow-hidden rounded-2xl border border-white/6"
              style={{ boxShadow: "0 8px 40px rgba(0,0,0,0.4)" }}>
              <iframe
                title="HAMMAD location"
                src="https://www.openstreetmap.org/export/embed.html?bbox=34.7%2C31.3%2C35.6%2C32.6&layer=mapnik"
                className="h-56 w-full grayscale opacity-80"
                loading="lazy"
                style={{ filter: "invert(90%) hue-rotate(180deg) saturate(0.6) brightness(0.8)" }}
              />
            </div>
          </div>

          {/* ── Contact Form ── */}
          <form
            onSubmit={submit}
            className="glass rounded-3xl border border-white/6 p-8 md:p-10"
            style={{ background: "linear-gradient(145deg, rgba(18,16,12,0.9) 0%, rgba(10,8,6,0.9) 100%)" }}
          >
            <h3 className="font-display text-2xl tracking-wide mb-8" style={{ fontWeight: 800 }}>
              SEND A MESSAGE
            </h3>
            <div className="space-y-5">
              {[
                { k: "name", label: "Full Name", type: "text", placeholder: "John Doe" },
                { k: "email", label: "Email", type: "email", placeholder: "you@example.com" },
                { k: "phone", label: "Phone Number", type: "tel", placeholder: "+1 555 000 0000" },
              ].map((f) => (
                <div key={f.k}>
                  <label htmlFor={f.k} className="block text-[10px] font-bold uppercase tracking-[0.2em] text-brand mb-2">
                    {f.label}
                  </label>
                  <input
                    id={f.k}
                    type={f.type}
                    placeholder={f.placeholder}
                    value={(form as Record<string, string>)[f.k]}
                    onChange={(e) => setForm({ ...form, [f.k]: e.target.value })}
                    className="input-gold w-full rounded-xl border border-white/8 bg-white/4 px-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none transition-all"
                  />
                  {errors[f.k] && <p className="mt-1.5 text-xs text-destructive">{errors[f.k]}</p>}
                </div>
              ))}
              <div>
                <label htmlFor="message" className="block text-[10px] font-bold uppercase tracking-[0.2em] text-brand mb-2">
                  Message
                </label>
                <textarea
                  id="message"
                  rows={5}
                  placeholder="Tell us about your needs..."
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="input-gold w-full rounded-xl border border-white/8 bg-white/4 px-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none resize-none transition-all"
                />
                {errors.message && <p className="mt-1.5 text-xs text-destructive">{errors.message}</p>}
              </div>

              <button
                type="submit"
                className="btn-shine inline-flex w-full items-center justify-center gap-2.5 rounded-full bg-brand py-4 text-sm font-bold uppercase tracking-widest text-brand-foreground hover:opacity-90 transition-opacity cursor-pointer"
              >
                Send Message <Send className="h-4 w-4" />
              </button>

              {sent && (
                <div className="glass-gold rounded-xl border border-brand/20 px-4 py-3 text-center">
                  <p className="text-sm font-medium text-brand">
                    Message sent! We'll be in touch within 24 hours.
                  </p>
                </div>
              )}
            </div>
          </form>
        </div>
      </section>
    </>
  );
}
