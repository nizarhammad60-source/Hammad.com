/**
 * VideoEngine.tsx
 * ──────────────────────────────────────────────────────────────
 * Dual-mode video scrubbing engine:
 *   • SCROLL mode  → GSAP ScrollTrigger pins section, scrubs video
 *                    frame-by-frame (scrub: 0.8 = 800ms smooth lag)
 *   • MOUSE mode   → gsap.quickTo() maps cursor X to video.currentTime
 *                    with 0.3s ease-out smoothing
 * Both modes merge naturally via GSAP's internal RAF scheduler.
 * ──────────────────────────────────────────────────────────────
 */
import { useEffect, useRef, useCallback } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export type VideoEngineMode = "scroll" | "mouse" | "both";

interface VideoEngineProps {
  src: string;
  poster?: string;
  mode?: VideoEngineMode;
  /** Total scroll distance while pinned. Default: "400%" */
  scrollLength?: string;
  /** GSAP scrub lag in seconds. Default: 0.8 */
  scrubLag?: number;
  /** Overlay content rendered above video */
  children?: React.ReactNode;
  className?: string;
}

export function VideoEngine({
  src,
  poster,
  mode = "scroll",
  scrollLength = "400%",
  scrubLag = 0.8,
  children,
  className = "",
}: VideoEngineProps) {
  const wrapRef    = useRef<HTMLDivElement>(null);
  const stickyRef  = useRef<HTMLDivElement>(null);
  const videoRef   = useRef<HTMLVideoElement>(null);
  const ctxRef     = useRef<gsap.Context | null>(null);
  /* quickTo setter — created once video metadata is known */
  const quickSetRef = useRef<((v: number) => void) | null>(null);

  /* ── Build GSAP context after video metadata loads ── */
  const initGSAP = useCallback(() => {
    const video  = videoRef.current;
    const wrap   = wrapRef.current;
    if (!video || !wrap || !video.duration) return;

    /* Clean previous context if any */
    ctxRef.current?.revert();

    ctxRef.current = gsap.context(() => {

      /* ── SCROLL MODE ── */
      if (mode === "scroll" || mode === "both") {
        gsap.to(video, {
          currentTime: video.duration,
          ease: "none",
          scrollTrigger: {
            trigger: wrap,
            start: "top top",
            end: `+=${scrollLength}`,
            scrub: scrubLag,
            pin: stickyRef.current,
            anticipatePin: 1,
            invalidateOnRefresh: true,
          },
        });
      }

      /* ── MOUSE MODE ── */
      if (mode === "mouse" || mode === "both") {
        /* quickTo is ~6× faster than gsap.to for frequent updates */
        quickSetRef.current = gsap.quickTo(video, "currentTime", {
          duration: 0.3,
          ease: "power2.out",
        });
      }
    }, wrap);
  }, [mode, scrollLength, scrubLag]);

  /* ── Attach mouse listener ── */
  useEffect(() => {
    if (mode !== "mouse" && mode !== "both") return;

    const handleMouseMove = (e: MouseEvent) => {
      const video = videoRef.current;
      if (!video?.duration || !quickSetRef.current) return;
      const progress = e.clientX / window.innerWidth;
      quickSetRef.current(progress * video.duration);
    };

    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, [mode]);

  /* ── Init on metadata ready ── */
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    video.preload = "auto";
    video.load();

    const onReady = () => {
      /* Small delay so layout is painted */
      requestAnimationFrame(() => requestAnimationFrame(initGSAP));
    };

    if (video.readyState >= 2) onReady();
    else {
      video.addEventListener("loadedmetadata", onReady, { once: true });
      video.addEventListener("canplay", onReady, { once: true });
    }

    return () => {
      ctxRef.current?.revert();
      ScrollTrigger.getAll().forEach(t => t.kill());
    };
  }, [initGSAP]);

  return (
    <div ref={wrapRef} className={`relative ${className}`}>
      {/* ── Sticky viewport frame ── */}
      <div
        ref={stickyRef}
        style={{ position: "sticky", top: 0, height: "100vh", overflow: "hidden" }}
      >
        {/* VIDEO */}
        <video
          ref={videoRef}
          src={src}
          poster={poster}
          muted
          playsInline
          preload="auto"
          aria-hidden="true"
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
            objectFit: "cover",
            willChange: "transform",
            /* Cinematic colour grade */
            filter: "contrast(1.1) saturate(1.08) brightness(0.82)",
            transform: "scale(1.02)", /* tiny overflow to hide edge flicker */
          }}
        />

        {/* ── Letterbox bars ── */}
        <div style={{ position:"absolute", inset:0, zIndex:4, pointerEvents:"none",
          boxShadow:"inset 0 0 0 0, inset 0 12vh 0 #000, inset 0 -12vh 0 #000" }} />

        {/* ── Film grain ── */}
        <div aria-hidden="true" style={{
          position:"absolute", inset:0, zIndex:5, pointerEvents:"none", opacity:0.04,
          backgroundImage:`url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='g'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.82' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23g)'/%3E%3C/svg%3E")`,
          backgroundSize:"256px 256px",
        }}/>

        {/* ── Multi-layer overlay ── */}
        <div style={{ position:"absolute", inset:0, zIndex:6, pointerEvents:"none",
          background:"linear-gradient(180deg,rgba(0,0,0,.52) 0%,rgba(0,0,0,.04) 22%,rgba(0,0,0,.04) 68%,rgba(0,0,0,.78) 100%)" }}/>
        <div style={{ position:"absolute", inset:0, zIndex:6, pointerEvents:"none",
          background:"radial-gradient(ellipse 92% 88% at 50% 50%, transparent 35%, rgba(0,0,0,.62) 100%)" }}/>
        <div style={{ position:"absolute", inset:0, zIndex:6, pointerEvents:"none",
          background:"radial-gradient(ellipse 65% 55% at 50% 50%, rgba(212,169,41,.035) 0%, transparent 58%)" }}/>

        {/* ── Slot for overlay content ── */}
        {children && (
          <div style={{ position:"absolute", inset:0, zIndex:20 }}>
            {children}
          </div>
        )}
      </div>
    </div>
  );
}
