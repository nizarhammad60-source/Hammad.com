/**
 * index.tsx — HAMMAD Cinematic Homepage
 * ═══════════════════════════════════════════════════════════════
 * Rendering stack:
 *   CinematicSection → CinematicVideoPlayer → WebGL + PIXI.js
 *   Frame extraction → seek+draw → GPU VRAM upload
 *   Physics          → spring-damper inertia
 *   Shader           → sub-frame blend + motion blur + grade
 *   ScrollTrigger    → real-time progress → physics target
 * ═══════════════════════════════════════════════════════════════
 */
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ShieldCheck, Truck, Award, Lock, Star } from "lucide-react";
import { motion } from "framer-motion";
import { useEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

import { CinematicSection }            from "@/components/site/CinematicSection";
import { AnimatedText, MagneticBtn }   from "@/components/site/AnimatedText";

import promoVideo from "@/assets/promo-video.mp4";
import heroVideo  from "@/assets/hero-video.mp4";
import mountain1  from "@/assets/mountain1.jpg";

import { categoriesMeta } from "@/lib/products";
import { useProducts }     from "@/lib/queries";
import { ProductCard }     from "@/components/site/ProductCard";

gsap.registerPlugin(ScrollTrigger);

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "HAMMAD — Gear Up. Move Better. Perform Stronger." },
      { name: "description", content: "Premium sports equipment engineered for athletes." },
    ],
  }),
  component: Home,
});

/* ── Scroll-reveal hook ──────────────────────────────────────────── */
function useScrollReveal() {
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>("[data-reveal]").forEach(el => {
        gsap.from(el, {
          y: 40, opacity: 0, scale: 0.97, duration: 0.9, ease: "expo.out",
          scrollTrigger: { trigger: el, start: "top 88%", toggleActions: "play none none none" },
        });
      });
    });
    return () => ctx.revert();
  }, []);
}

/* ── Promise cards data ──────────────────────────────────────────── */
const PROMISES = [
  { icon: Award,       t: "Premium Quality",  d: "Tested by athletes in studios and stadiums worldwide." },
  { icon: Truck,       t: "Fast Delivery",    d: "Express shipping within 48 hours globally." },
  { icon: ShieldCheck, t: "Trusted Gear",     d: "Hand-picked by performance specialists." },
  { icon: Lock,        t: "Secure Shopping",  d: "Encrypted checkout, protected returns." },
];

/* ════════════════════════════════════════════════════════════════════
   HOME
════════════════════════════════════════════════════════════════════ */
function Home() {
  useScrollReveal();
  const { data: products = [], isLoading } = useProducts();
  const featured = products.filter(p => p.featured).slice(0, 4);
  const showcase = featured.length > 0 ? featured : products.slice(0, 4);

  return (
    <>
      {/* ══════════════════════════════════════════════════════════
          CINEMATIC SECTION 1 — Hero
          WebGL engine: 90 frames, GPU-rendered, physics scrub
      ══════════════════════════════════════════════════════════ */}
      <CinematicSection
        src={promoVideo}
        poster={mountain1}
        frameCount={90}
        scrollHeight="340vh"
      >
        <div style={{
          height:"100%", display:"flex", flexDirection:"column",
          alignItems:"center", justifyContent:"center",
          textAlign:"center", padding:"0 1.5rem",
        }}>
          {/* Eyebrow badge */}
          <motion.div
            initial={{ opacity:0, y:18 }}
            animate={{ opacity:1, y:0 }}
            transition={{ duration:0.9, ease:[0.16,1,0.3,1], delay:0.4 }}
            style={{
              display:"inline-flex", alignItems:"center", gap:"10px",
              background:"rgba(212,169,41,.09)", border:"1px solid rgba(212,169,41,.35)",
              borderRadius:"100px", padding:"8px 24px",
              backdropFilter:"blur(20px)", marginBottom:"2.5rem",
            }}
          >
            <span style={{ width:6, height:6, borderRadius:"50%", background:"#D4A929", animation:"gold-pulse 2s ease infinite" }} />
            <span style={{ fontFamily:"'Barlow', sans-serif", fontSize:"11px", fontWeight:700, letterSpacing:"0.3em", textTransform:"uppercase", color:"#D4A929" }}>
              2026 Performance Edit
            </span>
          </motion.div>

          {/* Headline — char-split stagger */}
          <AnimatedText text="GEAR UP."   tag="h1" onScroll={false} delay={0.5} stagger={0.045}
            style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:900, fontSize:"clamp(5rem,14vw,13rem)", lineHeight:0.86, letterSpacing:"0.02em", textTransform:"uppercase", color:"#fff", textShadow:"0 8px 80px rgba(0,0,0,.55)" }} />
          <AnimatedText text="PERFORM" tag="h1" onScroll={false} delay={0.68} stagger={0.045}
            style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:900, fontSize:"clamp(5rem,14vw,13rem)", lineHeight:0.86, letterSpacing:"0.02em", textTransform:"uppercase",
              background:"linear-gradient(135deg,#D4A929 0%,#F5D060 42%,#B8860B 72%,#D4A929 100%)",
              WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", backgroundClip:"text",
              filter:"drop-shadow(0 0 40px rgba(212,169,41,.5))" }} />
          <AnimatedText text="STRONGER." tag="h1" onScroll={false} delay={0.86} stagger={0.045}
            style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:900, fontSize:"clamp(5rem,14vw,13rem)", lineHeight:0.86, letterSpacing:"0.02em", textTransform:"uppercase", color:"#fff", textShadow:"0 8px 80px rgba(0,0,0,.55)", marginBottom:"0.6em" }} />

          <motion.p
            initial={{ opacity:0, y:20 }}
            animate={{ opacity:1, y:0 }}
            transition={{ duration:1, ease:[0.16,1,0.3,1], delay:1.1 }}
            style={{ fontFamily:"'Barlow',sans-serif", fontWeight:300, fontSize:"clamp(1rem,1.8vw,1.25rem)", color:"rgba(255,255,255,.6)", maxWidth:"520px", lineHeight:1.75, marginBottom:"3rem", textShadow:"0 2px 20px rgba(0,0,0,.6)" }}
          >
            Premium sports equipment engineered for athletes<br />who refuse to settle. Built to outlast every session.
          </motion.p>

          <motion.div initial={{ opacity:0, y:24 }} animate={{ opacity:1, y:0 }} transition={{ duration:1, ease:[0.16,1,0.3,1], delay:1.3 }}
            style={{ display:"flex", flexWrap:"wrap", gap:"14px", justifyContent:"center", marginBottom:"4rem" }}>
            <MagneticBtn as="a" href="/products" variant="gold">
              Shop Now <ArrowRight style={{ width:16, height:16 }} />
            </MagneticBtn>
            <MagneticBtn as="a" href="#collections" variant="ghost">
              Explore Collections
            </MagneticBtn>
          </motion.div>

          <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} transition={{ duration:1, delay:1.5 }}
            style={{ display:"flex", flexWrap:"wrap", gap:"3.5rem", justifyContent:"center" }}>
            {[{ k:"120K+", v:"Athletes" },{ k:"4.9★", v:"Avg Rating" },{ k:"48H", v:"Delivery" },{ k:"99%", v:"Satisfaction" }].map(({ k, v }) => (
              <div key={v} style={{ textAlign:"center" }}>
                <p style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:900, fontSize:"clamp(2.2rem,3.5vw,3rem)", lineHeight:1,
                  background:"linear-gradient(135deg,#D4A929,#F5D060)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", backgroundClip:"text" }}>{k}</p>
                <p style={{ fontFamily:"'Barlow',sans-serif", fontSize:"11px", letterSpacing:"0.22em", textTransform:"uppercase", color:"rgba(255,255,255,.4)", marginTop:"5px" }}>{v}</p>
              </div>
            ))}
          </motion.div>

          {/* Scroll cue */}
          <div style={{ position:"absolute", bottom:"9%", left:"50%", transform:"translateX(-50%)", textAlign:"center", pointerEvents:"none" }}>
            <p style={{ fontFamily:"'Barlow',sans-serif", fontSize:"10px", letterSpacing:"0.35em", textTransform:"uppercase", color:"rgba(255,255,255,.38)", marginBottom:"10px" }}>Scroll</p>
            <div style={{ width:"1px", height:"44px", margin:"0 auto", background:"linear-gradient(to bottom,rgba(212,169,41,.9),transparent)", animation:"fade-up 1.8s ease infinite" }}/>
          </div>
        </div>
      </CinematicSection>

      {/* ══════════════════════════════════════════════════════════
          CATEGORIES
      ══════════════════════════════════════════════════════════ */}
      <section id="collections" className="container-x py-28">
        <div className="flex items-end justify-between gap-6 mb-14">
          <div>
            <p className="text-[11px] uppercase tracking-[0.3em] text-brand font-bold mb-4">Collections</p>
            <AnimatedText text="SHOP BY CATEGORY" tag="h2"
              style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:800, fontSize:"clamp(2.5rem,5vw,4.5rem)", color:"var(--foreground)", lineHeight:1 }} />
          </div>
          <Link to="/products" data-cursor="text" data-cursor-label="All"
            className="hidden md:inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-brand transition-colors cursor-none">
            View all <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5 auto-rows-[180px]">
          {categoriesMeta.map((c, i) => (
            <Link key={c.name} to="/products" search={{ category: c.name }}
              data-reveal data-cursor="text" data-cursor-label="Shop"
              className={`card-hover group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-white/6 p-6 cursor-none ${i===0?"lg:row-span-2 lg:col-span-2":""}`}
              style={{ background: i===0 ? "linear-gradient(135deg,rgba(212,169,41,.07) 0%,rgba(15,13,10,1) 100%)" : "linear-gradient(145deg,rgba(18,16,12,1) 0%,rgba(10,8,6,1) 100%)" }}>
              <div className="absolute -right-8 -bottom-8 h-40 w-40 rounded-full pointer-events-none opacity-60 group-hover:opacity-100 transition-opacity duration-500"
                style={{ background:"radial-gradient(circle,rgba(212,169,41,.12) 0%,transparent 70%)" }} />
              <span className="text-xs text-muted-foreground font-sans relative z-10">{c.blurb}</span>
              <div className="relative z-10">
                <h3 className="font-display tracking-wide text-foreground" style={{ fontSize:i===0?"2.2rem":"1.3rem", fontWeight:800 }}>{c.name.toUpperCase()}</h3>
                <span className="mt-2 inline-flex items-center gap-1 text-xs font-bold uppercase tracking-widest text-brand">
                  Shop now <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════
          CINEMATIC SECTION 2 — Mid-page
          60 frames, mouse X scrubs via physics
      ══════════════════════════════════════════════════════════ */}
      <CinematicSection
        src={heroVideo}
        poster={mountain1}
        frameCount={60}
        scrollHeight="240vh"
      >
        <div style={{ height:"100%", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", textAlign:"center", padding:"0 1.5rem" }}>
          <p style={{ fontFamily:"'Barlow',sans-serif", fontSize:"11px", fontWeight:700, letterSpacing:"0.38em", textTransform:"uppercase", color:"#D4A929", marginBottom:"1.8rem" }}>2026 Season</p>
          <AnimatedText text="MOVE WITHOUT" tag="h2"
            style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:900, fontSize:"clamp(4rem,12vw,10rem)", lineHeight:0.86, textTransform:"uppercase", color:"#fff", textShadow:"0 4px 60px rgba(0,0,0,.55)" }} />
          <AnimatedText text="LIMITS." tag="h2"
            style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:900, fontSize:"clamp(4rem,12vw,10rem)", lineHeight:0.86, textTransform:"uppercase",
              background:"linear-gradient(135deg,#D4A929 0%,#F5D060 45%,#B8860B 78%,#D4A929 100%)",
              WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", backgroundClip:"text",
              filter:"drop-shadow(0 0 35px rgba(212,169,41,.45))", marginBottom:"3rem" }} />
          <MagneticBtn as="a" href="/products" variant="gold">
            Shop the Collection <ArrowRight style={{ width:16, height:16 }} />
          </MagneticBtn>
        </div>
      </CinematicSection>

      {/* ══════════════════════════════════════════════════════════
          PRODUCTS
      ══════════════════════════════════════════════════════════ */}
      <section className="container-x py-28">
        <div className="flex items-end justify-between gap-6 mb-14">
          <div>
            <p className="text-[11px] uppercase tracking-[0.3em] text-brand font-bold mb-4">Featured</p>
            <AnimatedText text="ELITE GEAR" tag="h2"
              style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:800, fontSize:"clamp(2.5rem,5vw,4.5rem)", color:"var(--foreground)", lineHeight:1 }} />
          </div>
          <Link to="/products" className="hidden md:inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-brand transition-colors cursor-none">
            All products <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        {isLoading ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length:4 }).map((_,i) => <div key={i} className="aspect-[4/5] animate-pulse rounded-2xl" style={{ background:"rgba(212,169,41,.04)" }}/>)}
          </div>
        ) : showcase.length === 0 ? (
          <div className="glass rounded-2xl border border-white/6 px-8 py-16 text-center">
            <p className="text-muted-foreground font-sans">No products yet.</p>
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {showcase.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        )}
      </section>

      {/* ══════════════════════════════════════════════════════════
          PROMISES
      ══════════════════════════════════════════════════════════ */}
      <section className="container-x py-16 pb-28">
        <div className="relative overflow-hidden rounded-3xl border border-white/6 p-10 md:p-16"
          style={{ background:"linear-gradient(135deg,rgba(18,16,12,1) 0%,rgba(8,7,6,1) 100%)" }}>
          <div className="absolute inset-0 pointer-events-none"
            style={{ background:"radial-gradient(ellipse 60% 50% at 50% 0%,rgba(212,169,41,.05) 0%,transparent 70%)" }}/>
          <div className="relative z-10 max-w-xl mb-14">
            <p className="text-[11px] uppercase tracking-[0.3em] text-brand font-bold mb-4">Why HAMMAD</p>
            <AnimatedText text="FOUR QUIET PROMISES." tag="h2"
              style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:800, fontSize:"clamp(2.5rem,5vw,4rem)", color:"var(--foreground)", lineHeight:1 }} />
          </div>
          <div className="relative z-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {PROMISES.map(({ icon:Icon, t, d }) => (
              <motion.div key={t} data-reveal
                whileHover={{ y:-6, transition:{ duration:0.35, ease:[0.16,1,0.3,1] } }}
                className="glass rounded-2xl p-6 border border-white/5 hover:border-brand/20 transition-colors duration-300">
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl glass-gold mb-5"><Icon className="h-5 w-5 text-brand"/></div>
                <h3 className="font-display text-base tracking-widest text-foreground mb-2" style={{ fontWeight:700, fontSize:"0.95rem" }}>{t.toUpperCase()}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed font-sans">{d}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="container-x pb-28">
        <div className="divider-gold mb-14"/>
        <div className="grid gap-5 md:grid-cols-3">
          {[
            { q:"The quality is unreal. I've never felt so prepared stepping into training.", n:"Omar A.", r:"Professional Sprinter" },
            { q:"HAMMAD gear changed how I train. Every piece is engineered to last.", n:"Lina K.", r:"CrossFit Champion" },
            { q:"Fast delivery, premium packaging, and products that actually perform.", n:"Khalid M.", r:"Football Coach" },
          ].map((t, i) => (
            <motion.div key={t.n} data-reveal data-cursor="text" data-cursor-label="★★★★★"
              initial={{ opacity:0, y:30 }} whileInView={{ opacity:1, y:0 }}
              viewport={{ once:true, margin:"-60px" }}
              transition={{ duration:0.8, ease:[0.16,1,0.3,1], delay:i*0.1 }}
              className="glass rounded-2xl border border-white/6 p-7 hover:border-brand/15 transition-all duration-300 cursor-none">
              <div className="flex gap-0.5 mb-4">{Array.from({length:5}).map((_,j) => <Star key={j} className="h-3.5 w-3.5 fill-brand text-brand"/>)}</div>
              <p className="text-sm text-foreground leading-relaxed font-sans italic">"{t.q}"</p>
              <div className="mt-5 flex items-center gap-3">
                <div className="h-9 w-9 rounded-full glass-gold flex items-center justify-center text-xs font-bold text-brand">{t.n[0]}</div>
                <div><p className="text-sm font-semibold text-foreground">{t.n}</p><p className="text-xs text-muted-foreground">{t.r}</p></div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </>
  );
}
