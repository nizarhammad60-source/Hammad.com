/**
 * FrameBlendShader.ts
 * ─────────────────────────────────────────────────────────────────
 * Custom PIXI.js GLSL shader that:
 *   1. Blends two adjacent frames for sub-frame interpolation
 *      (eliminates frame-jump artifacts at fractional positions)
 *   2. Applies dynamic motion blur proportional to playback velocity
 *      (cinematic depth cue — fast scroll = blurry, stopped = sharp)
 * ─────────────────────────────────────────────────────────────────
 */

/** GLSL vertex shader — standard passthrough */
export const VERTEX_SRC = `
  attribute vec2 aVertexPosition;
  attribute vec2 aTextureCoord;

  uniform mat3 projectionMatrix;
  varying vec2 vTextureCoord;

  void main(void) {
    gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);
    vTextureCoord = aTextureCoord;
  }
`;

/**
 * GLSL fragment shader
 * Uniforms injected per-frame from CinematicVideoPlayer.tick():
 *   uFrameA     — texture for floor(currentFrame)
 *   uFrameB     — texture for ceil(currentFrame)
 *   uBlend      — fract(currentFrame), 0.0..1.0
 *   uBlur       — |velocity| × BLUR_SCALE, 0.0..1.0
 *   uBlurDir    — normalized velocity direction on screen
 */
export const FRAGMENT_SRC = `
  precision mediump float;

  varying vec2 vTextureCoord;

  uniform sampler2D uFrameA;      /* floor frame  */
  uniform sampler2D uFrameB;      /* ceil  frame  */
  uniform float     uBlend;       /* 0.0 → 1.0    */
  uniform float     uBlur;        /* motion blur strength */
  uniform vec2      uBlurDir;     /* normalised direction */
  uniform float     uBrightness;  /* ambient grade 0.8-1.0 */
  uniform float     uContrast;    /* 1.0 = neutral */
  uniform float     uVignette;    /* 0.0 = off */

  /* ── Sub-frame interpolation ──────────────────────────── */
  vec4 interpolatedFrame(vec2 uv) {
    vec4 colA = texture2D(uFrameA, uv);
    vec4 colB = texture2D(uFrameB, uv);
    return mix(colA, colB, uBlend);
  }

  /* ── Directional motion blur (5 samples) ─────────────── */
  vec4 motionBlur(vec2 uv, float strength) {
    if (strength < 0.005) return interpolatedFrame(uv);

    vec4 acc  = vec4(0.0);
    float inv = 1.0 / 5.0;
    float s   = strength * 0.008;          /* scale to pixel space */

    for (int i = 0; i < 5; i++) {
      float t   = (float(i) - 2.0) * s;
      vec2  off = uBlurDir * t;
      acc += interpolatedFrame(uv + off);
    }
    return acc * inv;
  }

  /* ── Cinematic colour grade ───────────────────────────── */
  vec4 grade(vec4 color) {
    /* Contrast S-curve */
    vec3 c = color.rgb;
    c = (c - 0.5) * uContrast + 0.5;

    /* Brightness */
    c *= uBrightness;

    /* Subtle cold shadow / warm highlight split-tone */
    float lum = dot(c, vec3(0.299, 0.587, 0.114));
    vec3 shadow   = vec3(0.85, 0.9,  1.0);   /* blue-cold shadows */
    vec3 highlight= vec3(1.0,  0.97, 0.88);  /* warm highlights  */
    c *= mix(shadow, highlight, lum);

    return vec4(clamp(c, 0.0, 1.0), color.a);
  }

  /* ── Vignette ─────────────────────────────────────────── */
  float vignette(vec2 uv) {
    vec2 d = (uv - 0.5) * 2.0;
    return 1.0 - dot(d, d) * uVignette;
  }

  void main(void) {
    vec2 uv    = vTextureCoord;
    vec4 color = motionBlur(uv, uBlur);
         color = grade(color);
         color.rgb *= vignette(uv);
    gl_FragColor = color;
  }
`;

/** Uniform defaults */
export const DEFAULT_UNIFORMS = {
  uFrameA:    null as any,  /* set per-tick */
  uFrameB:    null as any,  /* set per-tick */
  uBlend:     0.0,
  uBlur:      0.0,
  uBlurDir:   [0.0, 1.0] as [number, number],
  uBrightness:0.88,
  uContrast:  1.08,
  uVignette:  0.28,
};
