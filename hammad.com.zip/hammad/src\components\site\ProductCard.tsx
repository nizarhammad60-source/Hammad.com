import { Link } from "@tanstack/react-router";
import { ShoppingCart, Eye } from "lucide-react";
import type { Product } from "@/lib/products";
import { useCart } from "@/lib/cart";

export function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();

  return (
    <div className="group card-hover rounded-2xl overflow-hidden border border-white/6 bg-card cursor-pointer"
      style={{ background: "linear-gradient(145deg, rgba(20,18,14,1) 0%, rgba(12,10,8,1) 100%)" }}
    >
      {/* Image */}
      <Link
        to="/products/$id"
        params={{ id: product.id }}
        className="relative block aspect-[4/5] overflow-hidden bg-secondary"
      >
        {/* Badge */}
        {product.badge && (
          <span className="absolute left-3 top-3 z-10 glass-gold rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-brand">
            {product.badge}
          </span>
        )}

        {/* Image / Placeholder */}
        {product.image_url ? (
          <img
            src={product.image_url}
            alt={product.name}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-108"
            style={{ transition: "transform 0.7s cubic-bezier(0.16,1,0.3,1)" }}
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-xs text-muted-foreground">
            No image
          </div>
        )}

        {/* Hover overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400" />

        {/* Quick view button */}
        <div className="absolute bottom-3 left-3 right-3 opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-400 ease-out">
          <Link
            to="/products/$id"
            params={{ id: product.id }}
            className="flex items-center justify-center gap-2 w-full glass rounded-full py-2.5 text-xs font-semibold text-foreground hover:bg-white/10 transition-all"
          >
            <Eye className="h-3.5 w-3.5" /> Quick View
          </Link>
        </div>
      </Link>

      {/* Info */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[10px] uppercase tracking-[0.2em] text-brand font-semibold">{product.category}</p>
            <Link to="/products/$id" params={{ id: product.id }}>
              <h3 className="mt-1 font-display text-base tracking-wide text-foreground leading-tight group-hover:text-brand transition-colors duration-200 truncate cursor-pointer">
                {product.name}
              </h3>
            </Link>
            <p className="mt-1 line-clamp-1 text-xs text-muted-foreground font-sans">{product.description}</p>
          </div>
          <div className="shrink-0 text-right">
            <p className="font-display text-xl text-gold-gradient font-bold">${Number(product.price).toFixed(0)}</p>
          </div>
        </div>

        {/* Add to Cart */}
        <button
          onClick={() => add(product.id)}
          className="btn-shine mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-brand py-3 text-xs font-bold uppercase tracking-widest text-brand-foreground transition-all hover:opacity-90 cursor-pointer"
        >
          <ShoppingCart className="h-3.5 w-3.5" />
          Add to Cart
        </button>
      </div>
    </div>
  );
}
