/**
 * PhysicsEngine.ts
 * ─────────────────────────────────────────────────────────────────
 * Spring-damper physics for frame position.
 * Simulates the inertia a physical slider would have:
 *
 *   Force    = (target - current) × SPRING   ← attraction toward target
 *   Damping  = velocity × (1 - INERTIA)      ← resistance proportional to speed
 *   Position = current + velocity             ← integration step
 *
 * This produces the distinctive "eases in, overshoots slightly,
 * settles" motion signature of luxury digital experiences.
 * ─────────────────────────────────────────────────────────────────
 */
export interface PhysicsState {
  position: number;
  velocity: number;
  acceleration: number;
}

export interface PhysicsConfig {
  /** Spring constant: how aggressively position chases target.
   *  0.04 = very gentle  |  0.15 = snappy  |  0.3 = instant */
  spring: number;

  /** Inertia retention: 0 = no inertia  |  0.95 = very floaty */
  inertia: number;

  /** Max velocity cap — prevents overshooting on large jumps */
  maxVelocity: number;

  /** Below this |velocity|, stop updating (saves RAF cycles) */
  restThreshold: number;
}

export const CINEMA_PHYSICS: PhysicsConfig = {
  spring:        0.09,
  inertia:       0.88,
  maxVelocity:   12,
  restThreshold: 0.001,
};

export const SNAP_PHYSICS: PhysicsConfig = {
  spring:        0.22,
  inertia:       0.72,
  maxVelocity:   20,
  restThreshold: 0.002,
};

export class PhysicsEngine {
  public state: PhysicsState = { position: 0, velocity: 0, acceleration: 0 };
  private config: PhysicsConfig;
  private target: number = 0;
  public isResting: boolean = false;

  constructor(config: PhysicsConfig = CINEMA_PHYSICS, initialPosition = 0) {
    this.config = config;
    this.state.position = initialPosition;
    this.target = initialPosition;
  }

  setTarget(t: number): void {
    this.target = t;
    this.isResting = false;
  }

  /**
   * Step one frame of physics simulation.
   * Call inside requestAnimationFrame — delta is in ms.
   * Returns current position.
   */
  step(deltaMs = 16.67): number {
    const { spring, inertia, maxVelocity, restThreshold } = this.config;
    const dt = Math.min(deltaMs, 50) / 16.67; /* normalise to 60fps units */

    const force = (this.target - this.state.position) * spring;
    this.state.velocity = (this.state.velocity + force * dt) * Math.pow(inertia, dt);
    this.state.velocity = Math.max(-maxVelocity, Math.min(maxVelocity, this.state.velocity));

    this.state.position += this.state.velocity * dt;

    if (
      Math.abs(this.state.velocity) < restThreshold &&
      Math.abs(this.target - this.state.position) < restThreshold
    ) {
      this.state.position = this.target;
      this.state.velocity = 0;
      this.isResting = true;
    }

    return this.state.position;
  }

  reset(position: number): void {
    this.state = { position, velocity: 0, acceleration: 0 };
    this.target = position;
    this.isResting = true;
  }

  /** Velocity magnitude — used for motion blur strength */
  get speed(): number {
    return Math.abs(this.state.velocity);
  }
}
