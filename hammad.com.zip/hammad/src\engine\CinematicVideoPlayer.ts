/**
 * CinematicVideoPlayer.ts — v2
 * ═══════════════════════════════════════════════════════════════════
 * GPU-accelerated, physics-driven cinematic player.
 *
 * Rendering: PIXI.js v7
 *   • Two PIXI.Sprite layers (frameA behind, frameB above)
 *   • frameB.alpha = fract(position) → sub-frame interpolation
 *   • PIXI.BlurFilter on container → dynamic motion blur
 *   • PIXI.ColorMatrixFilter → cinematic colour grade
 *   • All textures pre-loaded into GPU VRAM
 *
 * Physics: Spring-damper (PhysicsEngine.ts)
 *   • velocity += (target - pos) × SPRING
 *   • velocity ×= INERTIA
 *   • pos += velocity
 *   → Inertia feel: video "breathes" after fast scroll
 *
 * Frame extraction: HTML5 Video seek+draw
 *   • Hidden <video> seeks to N timestamps
 *   • Each frame drawn to offscreen <canvas>
 *   • Exported as JPEG → PIXI.Texture (GPU VRAM)
 *   • <video> discarded — never used for display
 * ═══════════════════════════════════════════════════════════════════
 */
import * as PIXI from "pixi.js";
import { PhysicsEngine, CINEMA_PHYSICS, type PhysicsConfig } from "./PhysicsEngine";

export interface CinematicConfig {
  frameCount:  number;
  jpegQuality: number;
  blurScale:   number;
  physics:     PhysicsConfig;
  background:  number;
  onProgress?: (p: number) => void;
}

const DEFAULT_CONFIG: CinematicConfig = {
  frameCount:   90,
  jpegQuality:  0.88,
  blurScale:    0.30,
  physics:      CINEMA_PHYSICS,
  background:   0x080706,
};

export class CinematicVideoPlayer {
  public readonly canvas: HTMLCanvasElement;
  public isReady = false;

  /* PIXI objects */
  private app:         PIXI.Application;
  private container:   PIXI.Container;
  private spriteA:     PIXI.Sprite;   /* floor frame  */
  private spriteB:     PIXI.Sprite;   /* ceil  frame  */
  private blurFilter:  PIXI.BlurFilter;
  private gradeFilter: PIXI.ColorMatrixFilter;

  /* Data */
  private textures: PIXI.Texture[] = [];

  /* Physics */
  private physics: PhysicsEngine;

  /* Loop */
  private rafId  = 0;
  private lastTs = 0;

  private cfg: CinematicConfig;

  private constructor(canvas: HTMLCanvasElement, cfg: CinematicConfig) {
    this.canvas = canvas;
    this.cfg    = cfg;
    this.physics = new PhysicsEngine(cfg.physics);

    this.app = new PIXI.Application({
      view:            canvas,
      width:           canvas.width,
      height:          canvas.height,
      backgroundColor: cfg.background,
      backgroundAlpha: 1,
      antialias:       false,
      resolution:      1,
      autoDensity:     false,
      powerPreference: "high-performance",
      /* Keep draw buffer so screenshots work */
      preserveDrawingBuffer: true,
    });

    /* ── Colour grade filter ─────────────────────────────────── */
    this.gradeFilter = new PIXI.ColorMatrixFilter();
    this.gradeFilter.contrast(0.1, false);  /* +10% contrast  */
    this.gradeFilter.saturate(0.08, false); /* +8% saturation */
    this.gradeFilter.brightness(0.88, false);

    /* ── Motion blur filter ──────────────────────────────────── */
    this.blurFilter       = new PIXI.BlurFilter(0, 3);
    this.blurFilter.blur  = 0;

    /* ── Sprite container ────────────────────────────────────── */
    this.container = new PIXI.Container();
    this.container.filters = [this.gradeFilter, this.blurFilter];

    /* Placeholder textures — replaced once frames load */
    this.spriteA = new PIXI.Sprite(PIXI.Texture.WHITE);
    this.spriteB = new PIXI.Sprite(PIXI.Texture.WHITE);
    this.spriteA.alpha = 1;
    this.spriteB.alpha = 0;

    this.container.addChild(this.spriteA, this.spriteB);
    this.app.stage.addChild(this.container);
  }

  /* ── Factory ─────────────────────────────────────────────────── */
  static async create(
    canvas: HTMLCanvasElement,
    videoSrc: string,
    cfg: Partial<CinematicConfig> = {},
  ): Promise<CinematicVideoPlayer> {
    const config = { ...DEFAULT_CONFIG, ...cfg };
    const player = new CinematicVideoPlayer(canvas, config);
    await player._extractFrames(videoSrc);
    player._scaleSprites();
    player._startLoop();
    return player;
  }

  /* ── Frame extraction ────────────────────────────────────────── */
  private async _extractFrames(videoSrc: string): Promise<void> {
    const video  = document.createElement("video");
    const canvas = document.createElement("canvas");
    const ctx    = canvas.getContext("2d")!;

    video.muted       = true;
    video.preload     = "auto";
    video.crossOrigin = "anonymous";
    video.playsInline = true;

    await new Promise<void>((resolve, reject) => {
      video.onloadedmetadata = () => resolve();
      video.onerror = () => reject(new Error("Video failed to load"));
      video.src = videoSrc;
    });

    canvas.width  = video.videoWidth  || 1280;
    canvas.height = video.videoHeight || 720;

    const N = this.cfg.frameCount;
    const D = video.duration;

    for (let i = 0; i < N; i++) {
      const t = (i / Math.max(N - 1, 1)) * D;

      await new Promise<void>(res => {
        video.addEventListener("seeked", res, { once: true });
        video.currentTime = t;
      });

      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const url = canvas.toDataURL("image/jpeg", this.cfg.jpegQuality);
      const tex = PIXI.Texture.from(url);
      this.textures.push(tex);
      this.cfg.onProgress?.((i + 1) / N);
    }

    /* Set initial frame */
    this.spriteA.texture = this.textures[0];
    this.spriteB.texture = this.textures[1] ?? this.textures[0];
    this.isReady = true;

    /* Cleanup */
    video.src = ""; video.load();
  }

  /* ── Scale sprites to fill canvas ───────────────────────────── */
  private _scaleSprites(): void {
    const { width, height } = this.app.renderer;
    const tW = this.textures[0]?.width  || 1280;
    const tH = this.textures[0]?.height || 720;
    const scale = Math.max(width / tW, height / tH);

    for (const sp of [this.spriteA, this.spriteB]) {
      sp.scale.set(scale);
      /* Centre */
      sp.x = (width  - tW * scale) / 2;
      sp.y = (height - tH * scale) / 2;
    }
  }

  /* ── 60fps physics + render loop ─────────────────────────────── */
  private _startLoop(): void {
    const tick = (ts: number) => {
      const delta = ts - (this.lastTs || ts);
      this.lastTs = ts;

      if (this.isReady && this.textures.length > 1) {
        const pos    = this.physics.step(delta || 16.67);
        const clamped = Math.max(0, Math.min(this.textures.length - 1, pos));

        /* Sub-frame interpolation */
        const floorIdx = Math.floor(clamped);
        const ceilIdx  = Math.min(floorIdx + 1, this.textures.length - 1);
        const blend    = clamped - floorIdx;

        this.spriteA.texture = this.textures[floorIdx];
        this.spriteB.texture = this.textures[ceilIdx];
        this.spriteB.alpha   = blend;   /* GPU alpha blending = frame interpolation */

        /* Dynamic motion blur: fast → blur, stopped → sharp */
        const speed = this.physics.speed;
        this.blurFilter.blur = Math.min(8, speed * this.cfg.blurScale);

        this.app.renderer.render(this.app.stage);
      }

      this.rafId = requestAnimationFrame(tick);
    };

    this.rafId = requestAnimationFrame(tick);
  }

  /* ── Public API ──────────────────────────────────────────────── */
  setProgress(p: number): void {
    this.physics.setTarget(p * (this.textures.length - 1));
  }

  setTargetFrame(frame: number): void {
    this.physics.setTarget(Math.max(0, Math.min(this.textures.length - 1, frame)));
  }

  snapToFrame(frame: number): void {
    this.physics.reset(frame);
  }

  resize(width: number, height: number): void {
    this.app.renderer.resize(width, height);
    this._scaleSprites();
  }

  get currentPosition(): number { return this.physics.state.position; }
  get isResting():       boolean { return this.physics.isResting; }

  destroy(): void {
    cancelAnimationFrame(this.rafId);
    this.textures.forEach(t => t.destroy(true));
    this.textures = [];
    this.app.destroy(false, { children: true, texture: false });
    this.isReady = false;
  }
}
