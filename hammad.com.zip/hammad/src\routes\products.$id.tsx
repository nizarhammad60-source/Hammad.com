import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Check, ShieldCheck, Truck, RotateCcw, Minus, Plus, ShoppingCart, Star } from "lucide-react";
import { useCart } from "@/lib/cart";
import { ProductCard } from "@/components/site/ProductCard";
import { useProduct, useProducts } from "@/lib/queries";
import { useState } from "react";

export const Route = createFileRoute("/products/$id")({
  head: () => ({
    meta: [{ title: "Product — HAMMAD" }],
  }),
  component: ProductDetail,
});

function ProductDetail() {
  const { id } = Route.useParams();
  const { data: product, isLoading } = useProduct(id);
  const { data: allProducts = [] } = useProducts();
  const { add } = useCart();
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    add(product!.id, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  if (isLoading) {
    return (
      <div className="container-x py-20">
        <div className="grid gap-12 lg:grid-cols-2">
          <div className="aspect-square animate-pulse rounded-3xl" style={{ background: "rgba(212,169,41,0.05)" }} />
          <div className="space-y-5">
            {[40, 60, 30, 80, 50].map((w, i) => (
              <div key={i} className="h-5 animate-pulse rounded-xl" style={{ width: `${w}%`, background: "rgba(212,169,41,0.05)" }} />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container-x py-32 text-center">
        <h1 className="font-display text-5xl mb-6" style={{ fontWeight: 900 }}>PRODUCT NOT FOUND</h1>
        <Link to="/products"
          className="inline-flex h-12 items-center gap-2 rounded-full bg-brand px-8 text-sm font-bold text-brand-foreground hover:opacity-90 cursor-pointer">
          <ArrowLeft className="h-4 w-4" /> Back to Shop
        </Link>
      </div>
    );
  }

  const related = allProducts.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 3);

  return (
    <div className="relative">
      {/* Ambient */}
      <div className="orb w-[600px] h-[600px] top-0 right-0 pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(212,169,41,0.06) 0%, transparent 65%)" }} />

      <div className="container-x py-10 md:py-16">
        {/* Back */}
        <Link to="/products"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-brand transition-colors mb-10 group cursor-pointer">
          <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
          Back to Products
        </Link>

        <div className="grid gap-12 lg:grid-cols-2 lg:gap-20">
          {/* ── Image ── */}
          <div className="relative aspect-square overflow-hidden rounded-3xl border border-white/6"
            style={{
              background: "linear-gradient(145deg, rgba(18,16,12,1) 0%, rgba(10,8,6,1) 100%)",
              boxShadow: "0 40px 100px rgba(0,0,0,0.6), 0 0 0 1px rgba(212,169,41,0.08)",
            }}>
            {product.badge && (
              <span className="absolute left-5 top-5 z-10 glass-gold rounded-full border border-brand/20 px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest text-brand">
                {product.badge}
              </span>
            )}
            <div className="absolute inset-0 z-10 bg-gradient-to-br from-brand/5 via-transparent to-transparent pointer-events-none" />
            {product.image_url ? (
              <img src={product.image_url} alt={product.name} className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-xs text-muted-foreground">No image</div>
            )}
          </div>

          {/* ── Info ── */}
          <div className="flex flex-col justify-center">
            {/* Category + Rating */}
            <div className="flex items-center justify-between gap-4 mb-5">
              <p className="text-[11px] uppercase tracking-[0.25em] text-brand font-bold">{product.category}</p>
              <div className="flex items-center gap-1.5 glass rounded-full border border-white/8 px-3 py-1.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-3 w-3 fill-brand text-brand" />
                ))}
                <span className="text-[11px] text-muted-foreground ml-1">4.9</span>
              </div>
            </div>

            <h1 className="font-display leading-[0.9] tracking-[0.02em] text-balance mb-5"
              style={{ fontSize: "clamp(2.2rem, 4vw, 3.8rem)", fontWeight: 900 }}>
              {product.name.toUpperCase()}
            </h1>

            <p className="text-base text-muted-foreground leading-relaxed font-sans mb-8">{product.description}</p>

            {/* Price */}
            <div className="flex items-end gap-3 mb-10">
              <p className="font-display text-gold-gradient leading-none" style={{ fontSize: "3rem", fontWeight: 900 }}>
                ${Number(product.price).toFixed(2)}
              </p>
              <p className="text-xs text-muted-foreground mb-2 font-sans">Incl. taxes & free shipping</p>
            </div>

            {/* Qty + Add */}
            <div className="flex items-center gap-3 mb-8">
              <div className="inline-flex items-center glass rounded-full border border-white/8">
                <button
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="flex h-12 w-12 items-center justify-center text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
                  aria-label="Decrease quantity"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="w-10 text-center text-sm font-semibold">{qty}</span>
                <button
                  onClick={() => setQty((q) => q + 1)}
                  className="flex h-12 w-12 items-center justify-center text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
                  aria-label="Increase quantity"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
              <button
                onClick={handleAdd}
                disabled={added}
                className={`btn-shine flex-1 rounded-full py-3.5 text-sm font-bold uppercase tracking-widest transition-all cursor-pointer ${
                  added
                    ? "bg-sport/20 border border-sport/30 text-sport"
                    : "bg-brand text-brand-foreground hover:opacity-90"
                }`}
              >
                <span className="flex items-center justify-center gap-2">
                  {added ? (
                    <><Check className="h-4 w-4" /> Added to Cart</>
                  ) : (
                    <><ShoppingCart className="h-4 w-4" /> Add to Cart</>
                  )}
                </span>
              </button>
            </div>

            {/* Long description */}
            {product.long_description && (
              <div className="glass rounded-2xl border border-white/6 p-5 mb-8">
                <p className="text-sm text-foreground leading-relaxed font-sans">{product.long_description}</p>
              </div>
            )}

            {/* Features */}
            <ul className="space-y-3 mb-8">
              {[
                "Tested by professional athletes",
                "Premium materials, hand-finished",
                "30-day satisfaction guarantee",
              ].map((f) => (
                <li key={f} className="flex items-center gap-3 text-sm text-muted-foreground font-sans">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full glass-gold border border-brand/20 flex-shrink-0">
                    <Check className="h-3 w-3 text-brand" />
                  </span>
                  {f}
                </li>
              ))}
            </ul>

            {/* Guarantees */}
            <div className="grid grid-cols-3 gap-3 border-t border-white/6 pt-6">
              {[
                { icon: Truck, label: "48h shipping" },
                { icon: RotateCcw, label: "30-day returns" },
                { icon: ShieldCheck, label: "2-year warranty" },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="glass rounded-xl border border-white/5 p-3 text-center">
                  <Icon className="h-4 w-4 text-brand mx-auto mb-1.5" />
                  <p className="text-[11px] text-muted-foreground font-sans">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── Related Products ── */}
        {related.length > 0 && (
          <section className="mt-28">
            <div className="divider-gold mb-12" />
            <div className="flex items-end justify-between mb-10">
              <div>
                <p className="text-[11px] uppercase tracking-[0.3em] text-brand font-bold mb-3">Related</p>
                <h2 className="font-display leading-none tracking-wide"
                  style={{ fontSize: "clamp(2rem, 4vw, 3.5rem)", fontWeight: 900 }}>
                  YOU MAY ALSO LIKE
                </h2>
              </div>
            </div>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
